# Study Flow — Phase 3: Integration & Connections

Phase 3 connects the XML frontend from Phase 1 to the Java backend from Phase 2.

## Integrated flows
- Login by username, email, or mobile + password
- Guest entry
- Create account and validation
- Username recovery
- Account details editing
- Password reset from Settings
- Logout and study-data reset
- Home daily/weekly/monthly progress
- Home date/month filtering
- Dynamic subject/task lists
- Add/edit/delete/reset subject/task
- Launch selected work from Tasks into Clock
- Subject/task selection in Clock
- Stopwatch pause/resume/save
- Timer configuration/start/pause/resume without progress persistence
- Subject target slider
- Task reminders with date/time selection and local alarm integration
- Settings dark-mode preference
- About Us screen
- Fixed bottom navigation and profile avatar → Settings

## Intentionally deferred to Phase 4
- Gradle Kotlin DSL files
- Plugin/dependency versions
- SDK/build configuration

## Integration notes
The existing Phase 2 backend uses `LocalStore` for device-local persistence. The UI uses that backend through `AppBackend` and does not introduce a cloud/API dependency.
