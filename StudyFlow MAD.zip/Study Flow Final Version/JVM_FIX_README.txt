Study Flow - JVM compatibility fix

This project is configured for Android Gradle Plugin 9.4.0 / Gradle 9.6.0,
which requires JDK 17 or newer.

Android Studio project metadata now selects GRADLE_LOCAL_JAVA_HOME so the
project uses Android Studio's compatible local JDK instead of an incompatible
system JDK.

Existing Gradle build files were not modified by this fix.

If Android Studio still reports a JVM error, open:
Settings > Build, Execution, Deployment > Build Tools > Gradle
and select the bundled/compatible JDK 17+ for Gradle.
