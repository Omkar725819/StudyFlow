# Study Flow — Phase 2: Backend (Java)

Phase 2 implements the application backend independently of the XML UI.

## Implemented
- Local offline account persistence using SharedPreferences + JSON
- Login by username, email, or mobile number + password
- Guest mode
- Username/password recovery flows
- Account editing and password change/reset
- Subject and task CRUD
- Subject target management
- Stopwatch state management
- Persistent stopwatch progress sessions
- Daily, weekly, and monthly aggregation
- Work-level statistics
- Timer state management (timer completion is never saved as study progress)
- Reminder persistence and AlarmManager scheduling
- Reminder notification receiver with notification sound
- Dark-mode preference persistence
- Central backend composition root (`AppBackend`)
- Common `HH:MM:SS` formatter

## Phase Boundary
No XML wiring, Activity navigation, click listeners, adapters, manifest registration, or Gradle configuration is included here. Those are intentionally deferred to Phase 3 and Phase 4.
