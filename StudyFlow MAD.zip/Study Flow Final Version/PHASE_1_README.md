# Study Flow — Phase 1: Frontend (XML)

This phase contains the XML-only frontend for the Study Flow native Android application.

## Included
- Login screen
- Create Account screen
- Forgot Username screen
- Forgot Password screen
- Home screen
- Tasks screen
- Clock screen
- Settings screen
- About Us screen
- Add/Edit Subject dialogs
- Add/Edit Task dialogs
- Delete confirmation
- Reset Progress confirmation
- Progress filtering UI
- Account details editor
- Reset Password dialog
- Reminder dialog
- Saved Progress notification UI
- Progress details UI
- Logout confirmation
- Shared top bar and fixed bottom navigation
- Light/dark color resources
- Rounded surface, button, input, pill, avatar, and warning drawables
- Native vector icons
- Basic fade transition resources

## Phase Boundary
No Java application logic, Gradle configuration, manifest integration, persistence, notification scheduling, authentication logic, or screen navigation logic has been implemented in this phase.

## Font Note
The UI is prepared for the requested SF Pro-style visual treatment. No SF Pro font binary was added because the source prompt did not provide a font asset.
