# Study Flow release rules.
# No custom shrinking rules are currently required.
