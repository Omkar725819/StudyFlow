package com.studyflow.studytracker.ui;
import android.app.*;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.*;import android.view.*;import android.widget.*;import java.util.*;import com.studyflow.studytracker.R;import com.studyflow.studytracker.model.*;import com.studyflow.studytracker.util.TimeFormatter;
public class ClockActivity extends BaseActivity{
 public static String selectedWorkId;private boolean subjectMode=true, stopwatchMode=true;private Handler h=new Handler(Looper.getMainLooper());private Runnable ticker;private TextView value,selectedName,label,targetValue,startAction;private ImageView pauseAction;private LinearLayout targetDeck,reminderDeck;private NumberPicker hoursPicker,minutesPicker,secondsPicker;private long pendingTargetMillis;private static final long MAX_TARGET_MILLIS=24L*60L*60L*1000L;
 @Override protected void onCreate(Bundle b){
  super.onCreate(b);setContentView(R.layout.activity_clock);bindBottomNav(getWindow().getDecorView());
  StudyWork restored=backend.stopwatch().getWorkId()==null?null:backend.work().find(backend.stopwatch().getWorkId());
  if(restored!=null){ selectedWorkId=restored.getId(); subjectMode=restored.getType()==StudyWork.Type.SUBJECT; } else { selectedWorkId=null; }
  value=findViewById(R.id.clock_value);selectedName=findViewById(R.id.selected_work_name);label=findViewById(R.id.selected_work_label);targetDeck=findViewById(R.id.subject_target_deck);reminderDeck=findViewById(R.id.reminder_deck);hoursPicker=findViewById(R.id.target_hours_picker);minutesPicker=findViewById(R.id.target_minutes_picker);secondsPicker=findViewById(R.id.target_seconds_picker);targetValue=findViewById(R.id.target_value);configureTargetPickers();
  startAction=findViewById(R.id.start_action);pauseAction=findViewById(R.id.pause_action);
  findViewById(R.id.clock_subjects_tab).setOnClickListener(v->{subjectMode=true;updateWorkModeSelection();refreshWorks();});
  findViewById(R.id.clock_tasks_tab).setOnClickListener(v->{subjectMode=false;updateWorkModeSelection();refreshWorks();});
  findViewById(R.id.stopwatch_tab).setOnClickListener(v->{showStopwatch();});
  findViewById(R.id.timer_tab).setOnClickListener(v->{showTimerMode();});
  findViewById(R.id.work_options).setOnClickListener(v->chooseWork());
  startAction.setOnClickListener(v->startAction());
  pauseAction.setOnClickListener(v->togglePauseResume());
  findViewById(R.id.save_progress_action).setOnClickListener(v->saveProgress());
  findViewById(R.id.save_target_action).setOnClickListener(v->saveTarget());
  findViewById(R.id.add_reminder_action).setOnClickListener(v->addReminder());
  findViewById(R.id.view_reminders_action).setOnClickListener(v->startActivity(new Intent(this,RemindersActivity.class)));
  refreshWorks();updateWorkModeSelection();showStopwatch();updateControlVisibility();
 }
 @Override protected void onResume(){super.onResume();startTicker();}
 @Override protected void onPause(){super.onPause();if(ticker!=null)h.removeCallbacks(ticker);}
 @Override protected void onDestroy(){if(ticker!=null)h.removeCallbacks(ticker);super.onDestroy();}
 private void refreshWorks(){
  List<StudyWork> list=subjectMode?backend.work().getSubjects():backend.work().getTasks();
  label.setText(subjectMode?"Selected Subject":"Selected Task");
  animateVisibility(targetDeck, subjectMode);
  animateVisibility(reminderDeck, !subjectMode);
  StudyWork current=selectedWorkId==null?null:backend.work().find(selectedWorkId);
  boolean stopwatchRunning=backend.stopwatch().isRunning();
  if(!stopwatchRunning && (current==null || current.getType()!=(subjectMode?StudyWork.Type.SUBJECT:StudyWork.Type.TASK))) selectedWorkId=list.isEmpty()?null:list.get(0).getId();
  StudyWork w=selectedWorkId==null?null:backend.work().find(selectedWorkId);
  if(stopwatchRunning && backend.stopwatch().getWorkId()!=null){
    StudyWork runningWork=backend.work().find(backend.stopwatch().getWorkId());
    if(runningWork!=null){ selectedWorkId=runningWork.getId(); w=runningWork; label.setText(runningWork.getType()==StudyWork.Type.SUBJECT?"Selected Subject":"Selected Task"); }
  }
  selectedName.setText(w==null?(subjectMode?"No subjects":"No tasks"):w.getName());
  if(w!=null){
    if(!w.getId().equals(backend.stopwatch().getWorkId())) backend.stopwatch().selectWork(w.getId());
    if(subjectMode){pendingTargetMillis=clampTarget(w.getTargetMillis()); setTargetPickerValue(pendingTargetMillis); targetValue.setText("Target: "+fmt(pendingTargetMillis));}
  }
 }
 private void chooseWork(){if(backend.stopwatch().isRunning()){toast("Pause or save the current stopwatch before changing work");return;} List<StudyWork> list=subjectMode?backend.work().getSubjects():backend.work().getTasks();String[] names=new String[list.size()];for(int i=0;i<list.size();i++)names[i]=list.get(i).getName();new AlertDialog.Builder(this).setTitle(subjectMode?"Select Subject":"Select Task").setItems(names,(d,w)->{selectedWorkId=list.get(w).getId();backend.stopwatch().selectWork(selectedWorkId);selectedName.setText(list.get(w).getName());if(subjectMode){StudyWork selected=backend.work().find(selectedWorkId);pendingTargetMillis=selected==null?0:clampTarget(selected.getTargetMillis());setTargetPickerValue(pendingTargetMillis);targetValue.setText("Target: "+fmt(pendingTargetMillis));}}).setNegativeButton("Cancel",null).show();}
 private void showStopwatch(){stopwatchMode=true;animateVisibility(findViewById(R.id.timer_warning), false);startAction.setText("Start");updateClockTypeSelection();updateControlVisibility();startTicker();}
 private void showTimerMode(){stopwatchMode=false;animateVisibility(findViewById(R.id.timer_warning), true);startAction.setText("Start");updateClockTypeSelection();updateControlVisibility();startTicker();}
 private void updateClockTypeSelection(){
  TextView sw=findViewById(R.id.stopwatch_tab), tm=findViewById(R.id.timer_tab);
  if(stopwatchMode){
   sw.setBackgroundResource(R.drawable.bg_selected_pill); sw.setTextColor(getColor(android.R.color.white)); sw.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
   tm.setBackgroundResource(R.drawable.bg_pill); tm.setTextColor(getColor(R.color.sf_text_secondary)); tm.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
   animateSelection(sw, tm);
  } else {
   tm.setBackgroundResource(R.drawable.bg_selected_pill); tm.setTextColor(getColor(android.R.color.white)); tm.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
   sw.setBackgroundResource(R.drawable.bg_pill); sw.setTextColor(getColor(R.color.sf_text_secondary)); sw.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
   animateSelection(tm, sw);
  }
 }
 private void showTimerSetup(){final EditText m=new EditText(this);m.setHint("Minutes");m.setInputType(2);new AlertDialog.Builder(this).setTitle("Set Timer").setView(m).setNegativeButton("Cancel",null).setPositiveButton("Start",(d,w)->{try{long duration=Long.parseLong(m.getText().toString())*60000L;backend.timer().configure(duration);backend.timer().start();updateControlVisibility();startTicker();}catch(Exception e){toast("Enter a valid duration");}}).show();}
 private void startAction(){if(!stopwatchMode){if(!backend.timer().isRunning()){if(backend.timer().getRemainingMillis()<=0){showTimerSetup();}else backend.timer().start();updateControlVisibility();startTicker();}return;}if(selectedWorkId==null){toast("Select a subject or task first");return;}if(!backend.stopwatch().isRunning()){backend.stopwatch().start();updateControlVisibility();startTicker();}}
 private void togglePauseResume(){if(!stopwatchMode){if(backend.timer().isRunning()) backend.timer().pause();else if(backend.timer().getRemainingMillis()>0) backend.timer().resume();updateControlVisibility();startTicker();return;}if(backend.stopwatch().isRunning())backend.stopwatch().pause();else if(backend.stopwatch().getElapsedMillis()>0)backend.stopwatch().resume();updateControlVisibility();startTicker();}

 private void updateWorkModeSelection(){TextView subjects=findViewById(R.id.clock_subjects_tab),tasks=findViewById(R.id.clock_tasks_tab);if(subjectMode){subjects.setBackgroundResource(R.drawable.bg_selected_pill);subjects.setTextColor(getColor(android.R.color.white));subjects.setTypeface(Typeface.DEFAULT, Typeface.BOLD);tasks.setBackgroundResource(R.drawable.bg_pill);tasks.setTextColor(getColor(R.color.sf_text_secondary));tasks.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);animateSelection(subjects,tasks);}else{tasks.setBackgroundResource(R.drawable.bg_selected_pill);tasks.setTextColor(getColor(android.R.color.white));tasks.setTypeface(Typeface.DEFAULT, Typeface.BOLD);subjects.setBackgroundResource(R.drawable.bg_pill);subjects.setTextColor(getColor(R.color.sf_text_secondary));subjects.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);animateSelection(tasks,subjects);}}
 private void updateControlVisibility(){boolean running=stopwatchMode?backend.stopwatch().isRunning():backend.timer().isRunning();startAction.setVisibility(running?View.GONE:View.VISIBLE);pauseAction.setVisibility(running||((stopwatchMode&&backend.stopwatch().getElapsedMillis()>0)||(!stopwatchMode&&backend.timer().getRemainingMillis()>0))?View.VISIBLE:View.GONE);if(pauseAction!=null){pauseAction.setImageResource(stopwatchMode&&backend.stopwatch().isRunning()?R.drawable.ic_pause:R.drawable.ic_play);pauseAction.setContentDescription(stopwatchMode&&backend.stopwatch().isRunning()?"Pause":"Resume");}}
 private void configureTargetPickers(){hoursPicker.setMinValue(0);hoursPicker.setMaxValue(24);minutesPicker.setMinValue(0);minutesPicker.setMaxValue(59);secondsPicker.setMinValue(0);secondsPicker.setMaxValue(59);hoursPicker.setFormatter(v->String.format(Locale.US,"%02d",v));minutesPicker.setFormatter(v->String.format(Locale.US,"%02d",v));secondsPicker.setFormatter(v->String.format(Locale.US,"%02d",v));hoursPicker.setOnValueChangedListener((p, oldValue, newValue)->{if(newValue>=24){minutesPicker.setValue(0);secondsPicker.setValue(0);}updatePendingTargetFromPickers();});minutesPicker.setOnValueChangedListener((p, oldValue, newValue)->{if(hoursPicker.getValue()>=24&&newValue!=0)p.setValue(0);updatePendingTargetFromPickers();});secondsPicker.setOnValueChangedListener((p, oldValue, newValue)->{if(hoursPicker.getValue()>=24&&newValue!=0)p.setValue(0);updatePendingTargetFromPickers();});setTargetPickerValue(2L*60L*60L*1000L);}
 private void updatePendingTargetFromPickers(){int hh=Math.min(24,hoursPicker.getValue());int mm=hh>=24?0:Math.min(59,minutesPicker.getValue());int ss=hh>=24?0:Math.min(59,secondsPicker.getValue());pendingTargetMillis=Math.min(MAX_TARGET_MILLIS,(hh*3600L+mm*60L+ss)*1000L);targetValue.setText("Target: "+fmt(pendingTargetMillis));}
 private void setTargetPickerValue(long millis){long safe=clampTarget(millis);int totalSeconds=(int)(safe/1000L);int hh=Math.min(24,totalSeconds/3600);int rem=totalSeconds%3600;int mm=hh>=24?0:rem/60;int ss=hh>=24?0:rem%60;hoursPicker.setValue(hh);minutesPicker.setValue(mm);secondsPicker.setValue(ss);pendingTargetMillis=(hh*3600L+mm*60L+ss)*1000L;}
 private long clampTarget(long millis){return Math.max(0L,Math.min(MAX_TARGET_MILLIS,millis));}
 private void saveTarget(){if(!subjectMode||selectedWorkId==null){toast("Select a subject first");return;}updatePendingTargetFromPickers();if(pendingTargetMillis<=0){toast("Set a target first");return;}if(backend.work().setSubjectTarget(selectedWorkId,pendingTargetMillis)){targetValue.setText("Saved Target: "+fmt(pendingTargetMillis));toast("Target saved");}}
 private void saveProgress(){if(!stopwatchMode){toast("Timer time is not saved as study progress");return;}if(selectedWorkId==null){toast("Select a subject or task first");return;}StudyWork selected=backend.work().find(selectedWorkId);if(selected==null){selectedWorkId=null;toast("Selected subject or task no longer exists");return;}long ms=backend.stopwatch().saveAndReset();if(ms<=0){toast("No study time to save");return;}backend.progress().saveStopwatchProgress(selectedWorkId,ms);new AlertDialog.Builder(this).setTitle("Progress Saved").setMessage("Saved "+fmt(ms)+" for "+selected.getName()).setPositiveButton("OK",null).show();updateControlVisibility();startTicker();}
 private void startTicker(){if(ticker!=null)h.removeCallbacks(ticker);ticker=()->{long ms=stopwatchMode?backend.stopwatch().getElapsedMillis():backend.timer().getRemainingMillis();value.setText(fmt(ms));updateControlVisibility();if(stopwatchMode&&backend.stopwatch().isRunning()||!stopwatchMode&&backend.timer().isRunning())h.postDelayed(ticker,250);};h.post(ticker);}
 private void addReminder(){final View v=getLayoutInflater().inflate(R.layout.dialog_reminder,null,false);AlertDialog d=new AlertDialog.Builder(this).setView(v).create();v.findViewById(R.id.reminder_add).setOnClickListener(x->{EditText n=v.findViewById(R.id.reminder_name);DatePicker dp=v.findViewById(R.id.reminder_date);TimePicker tp=v.findViewById(R.id.reminder_time);Calendar c=Calendar.getInstance();c.set(dp.getYear(),dp.getMonth(),dp.getDayOfMonth(),tp.getHour(),tp.getMinute(),0);c.set(Calendar.MILLISECOND,0);try{backend.reminders().addReminder(n.getText().toString(),c.getTimeInMillis());toast("Reminder added");d.dismiss();}catch(Exception e){toast(e.getMessage());}});d.show();}
 private String fmt(long x){return TimeFormatter.formatHms(Math.max(0,x));}
}
