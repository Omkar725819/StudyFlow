package com.studyflow.studytracker.service;

import com.studyflow.studytracker.data.LocalStore;
import com.studyflow.studytracker.model.Account;
import java.util.Locale;
import com.studyflow.studytracker.util.PasswordHasher;

public class AccountService {
    private final LocalStore store;
    public AccountService(LocalStore store) { this.store = store; }

    public boolean createAccount(Account account) {
        if (!isValidAccount(account)) return false;
        Account existing = store.getAccount();
        if (existing != null) return false;
        account.setPasswordHash(PasswordHasher.hash(account.getPasswordHash()));
        store.saveAccount(account); store.setAccountMode(); return true;
    }

    public boolean authenticate(String identifier, String password) {
        Account a = store.getAccount();
        boolean ok = a != null && authenticateIdentifier(a, identifier) && PasswordHasher.verify(password, a.getPasswordHash());
        if (ok) store.setAccountMode();
        return ok;
    }

    private boolean authenticateIdentifier(Account a, String identifier) {
        String id = normalize(identifier);
        return id.equals(normalize(a.getUsername())) || id.equals(normalize(a.getEmail())) || id.equals(normalize(a.getMobileNumber()));
    }

    public String recoverUsername(String identifier, String pin) {
        Account a = store.getAccount();
        return a != null && authenticateIdentifier(a, identifier) && safeEquals(pin, a.getSecurityPin()) ? a.getUsername() : null;
    }

    public boolean resetPassword(String identifier, String pin, String newPassword) {
        Account a = store.getAccount();
        if (a == null || !authenticateIdentifier(a, identifier) || !safeEquals(pin, a.getSecurityPin()) || !validPassword(newPassword)) return false;
        a.setPasswordHash(PasswordHasher.hash(newPassword)); store.saveAccount(a); return true;
    }

    public boolean changePassword(String currentPassword, String newPassword) {
        Account a = store.getAccount();
        if (a == null || !PasswordHasher.verify(currentPassword, a.getPasswordHash()) || !validPassword(newPassword)) return false;
        a.setPasswordHash(PasswordHasher.hash(newPassword)); store.saveAccount(a); return true;
    }

    public boolean updateAccount(Account updated) {
        if (!isValidAccount(updated) || store.getAccount() == null) return false;
        store.saveAccount(updated); return true;
    }

    public Account getAccount() { return store.isGuestMode() ? null : store.getAccount(); }
    public Account getRegisteredAccount() { return store.getAccount(); }
    public boolean hasRegisteredAccount() { return store.getAccount() != null; }
    public void loginAsGuest() { store.setGuestMode(true); }
    public void loginAsAccount() { store.setAccountMode(); }
    public boolean isGuest() { return store.isGuestMode(); }
    public boolean isAccountSession() { return store.isAccountMode() && store.getAccount() != null; }
    public boolean hasActiveSession() { return isGuest() || isAccountSession(); }

    /** Log out without deleting the locally stored account or either profile's study data. */
    public void logoutAndReset() { store.setActiveProfile("none"); }

    private static boolean isValidAccount(Account a) {
        return a != null && nonEmpty(a.getUsername()) && nonEmpty(a.getEmail()) && nonEmpty(a.getMobileNumber())
                && validPassword(a.getPasswordHash()) && a.getSecurityPin() != null && a.getSecurityPin().matches("\\d{6}")
                && nonEmpty(a.getProfession()) && nonEmpty(a.getEducation()) && nonEmpty(a.getCollege());
    }
    private static boolean validPassword(String value) { return value != null && value.length() >= 6; }
    private static boolean nonEmpty(String value) { return value != null && !value.trim().isEmpty(); }
    private static boolean safeEquals(String a, String b) { return a != null && b != null && a.equals(b); }
    private static String normalize(String value) { return value == null ? "" : value.trim().toLowerCase(Locale.ROOT); }
}
