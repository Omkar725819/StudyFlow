package com.studyflow.studytracker.service;

import com.studyflow.studytracker.data.LocalStore;
import com.studyflow.studytracker.model.ProgressSession;
import com.studyflow.studytracker.model.StudyWork;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;

/** Rebuilds period counters so the Home/Tasks values automatically roll over with the calendar. */
public class ProgressRolloverService {
    private final LocalStore store;
    public ProgressRolloverService(LocalStore store) { this.store = store; }

    public void reconcile() {
        LocalDate today = LocalDate.now();
        LocalDate weekStart = today.minusDays(today.getDayOfWeek().getValue() - DayOfWeek.MONDAY.getValue());
        YearMonth month = YearMonth.from(today);
        List<ProgressSession> sessions = store.getSessions();
        List<StudyWork> works = store.getWorks();
        for (StudyWork work : works) {
            long day = 0L, week = 0L, mon = 0L;
            for (ProgressSession session : sessions) {
                if (!session.getWorkId().equals(work.getId())) continue;
                LocalDate date = session.getDate();
                if (date.equals(today)) day += session.getDurationMillis();
                if (!date.isBefore(weekStart) && !date.isAfter(today)) week += session.getDurationMillis();
                if (YearMonth.from(date).equals(month)) mon += session.getDurationMillis();
            }
            work.setPeriodMillis(day, week, mon);
        }
        store.saveWorks(works);
    }
}
