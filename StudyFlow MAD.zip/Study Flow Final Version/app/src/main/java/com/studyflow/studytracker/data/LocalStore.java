package com.studyflow.studytracker.data;

import android.content.Context;
import android.content.SharedPreferences;
import com.studyflow.studytracker.model.Account;
import com.studyflow.studytracker.model.Reminder;
import com.studyflow.studytracker.model.StudyWork;
import com.studyflow.studytracker.model.ProgressSession;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public final class LocalStore {
    private static final String PREFS = "study_flow_local_store";
    private static final String KEY_ACCOUNT = "account";
    private static final String KEY_PROFILE = "active_profile";
    private static final String PROFILE_NONE = "none";
    private static final String PROFILE_ACCOUNT = "account";
    private static final String PROFILE_GUEST = "guest";
    private static final String KEY_DARK = "dark_mode";
    private static final String KEY_WORKS = "works";
    private static final String KEY_SESSIONS = "sessions";
    private static final String KEY_REMINDERS = "reminders";
    private static final String KEY_GUEST_WORKS = "guest_works";
    private static final String KEY_GUEST_SESSIONS = "guest_sessions";
    private static final String KEY_GUEST_REMINDERS = "guest_reminders";
    private static final String KEY_STOPWATCH_WORK = "stopwatch_work";
    private static final String KEY_STOPWATCH_ACCUMULATED = "stopwatch_accumulated";
    private static final String KEY_STOPWATCH_STARTED = "stopwatch_started";
    private static final String KEY_STOPWATCH_RUNNING = "stopwatch_running";
    private static final String KEY_TIMER_DURATION = "timer_duration";
    private static final String KEY_TIMER_REMAINING = "timer_remaining";
    private static final String KEY_TIMER_STARTED = "timer_started";
    private static final String KEY_TIMER_RUNNING = "timer_running";

    private String profileStateKey(String base) {
        String prefix = isGuestMode() ? "guest_" : (isAccountMode() ? "account_" : "none_");
        return prefix + base;
    }
    private final SharedPreferences prefs;

    public LocalStore(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        migrateLegacyProfileState();
    }

    private void migrateLegacyProfileState() {
        if (prefs.contains(KEY_PROFILE)) return;
        String legacyProfile = prefs.getString("active_profile", null);
        if (PROFILE_GUEST.equals(legacyProfile) || PROFILE_ACCOUNT.equals(legacyProfile)) {
            prefs.edit().putString(KEY_PROFILE, legacyProfile).apply();
            return;
        }
        // Older builds used only guest_mode. For upgraded installs that already
        // contain a registered account, keep the user signed in rather than
        // unexpectedly returning to Login after an app/process restart.
        if (prefs.getBoolean("guest_mode", false)) {
            prefs.edit().putString(KEY_PROFILE, PROFILE_GUEST).apply();
        } else if (prefs.getString(KEY_ACCOUNT, null) != null) {
            prefs.edit().putString(KEY_PROFILE, PROFILE_ACCOUNT).apply();
        } else {
            prefs.edit().putString(KEY_PROFILE, PROFILE_NONE).apply();
        }
    }

    public void saveAccount(Account account) {
        if (account == null) return;
        try { prefs.edit().putString(KEY_ACCOUNT, account.toJson().toString()).commit(); }
        catch (Exception e) { throw new IllegalStateException("Unable to save account", e); }
    }

    public Account getAccount() {
        String value = prefs.getString(KEY_ACCOUNT, null);
        if (value == null || value.trim().isEmpty()) return null;
        try { return Account.fromJson(new JSONObject(value)); }
        catch (Exception ignored) { return null; }
    }

    public void clearAccount() { prefs.edit().remove(KEY_ACCOUNT).apply(); }

    /** Persist the currently selected local profile independently from the registered account. */
    public void setActiveProfile(String profile) {
        if (!PROFILE_ACCOUNT.equals(profile) && !PROFILE_GUEST.equals(profile)) profile = PROFILE_NONE;
        prefs.edit().putString(KEY_PROFILE, profile).apply();
    }

    public String getActiveProfile() { return prefs.getString(KEY_PROFILE, PROFILE_NONE); }
    public boolean hasActiveProfile() { return PROFILE_ACCOUNT.equals(getActiveProfile()) || PROFILE_GUEST.equals(getActiveProfile()); }
    public boolean isGuestMode() { return PROFILE_GUEST.equals(getActiveProfile()); }
    public boolean isAccountMode() { return PROFILE_ACCOUNT.equals(getActiveProfile()); }

    public void setGuestMode(boolean guest) { setActiveProfile(guest ? PROFILE_GUEST : PROFILE_NONE); }
    public void setAccountMode() { setActiveProfile(PROFILE_ACCOUNT); }
    public void setDarkMode(boolean enabled) { prefs.edit().putBoolean(KEY_DARK, enabled).apply(); }
    public boolean isDarkMode() { return prefs.getBoolean(KEY_DARK, false); }

    private String worksKey() { return isGuestMode() ? KEY_GUEST_WORKS : (isAccountMode() ? KEY_WORKS : null); }
    private String sessionsKey() { return isGuestMode() ? KEY_GUEST_SESSIONS : (isAccountMode() ? KEY_SESSIONS : null); }
    private String remindersKey() { return isGuestMode() ? KEY_GUEST_REMINDERS : (isAccountMode() ? KEY_REMINDERS : null); }

    public List<StudyWork> getWorks() {
        List<StudyWork> result = new ArrayList<>();
        String key = worksKey();
        if (key == null) return result;
        String raw = prefs.getString(key, "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                try {
                    StudyWork work = StudyWork.fromJson(a.optJSONObject(i));
                    if (work != null) result.add(work);
                } catch (Exception ignored) { /* skip malformed record */ }
            }
        } catch (Exception ignored) { /* treat malformed store as empty, without crashing */ }
        return result;
    }

    public void saveWorks(List<StudyWork> works) {
        JSONArray a = new JSONArray();
        if (works != null) {
            for (StudyWork w : works) {
                if (w == null) continue;
                try { a.put(w.toJson()); } catch (Exception ignored) { /* skip only bad row */ }
            }
        }
        String key = worksKey();
        if (key != null) prefs.edit().putString(key, a.toString()).apply();
    }

    public List<ProgressSession> getSessions() {
        List<ProgressSession> result = new ArrayList<>();
        String key = sessionsKey();
        if (key == null) return result;
        String raw = prefs.getString(key, "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                try {
                    ProgressSession session = ProgressSession.fromJson(a.optJSONObject(i));
                    if (session != null) result.add(session);
                } catch (Exception ignored) { /* skip malformed record */ }
            }
        } catch (Exception ignored) { /* treat malformed store as empty */ }
        return result;
    }

    public void saveSessions(List<ProgressSession> sessions) {
        JSONArray a = new JSONArray();
        if (sessions != null) {
            for (ProgressSession s : sessions) {
                if (s == null) continue;
                try { a.put(s.toJson()); } catch (Exception ignored) { }
            }
        }
        String key = sessionsKey();
        if (key != null) prefs.edit().putString(key, a.toString()).apply();
    }

    public void removeSessionsForWork(String workId) {
        if (workId == null || workId.trim().isEmpty()) return;
        List<ProgressSession> sessions = getSessions();
        sessions.removeIf(session -> workId.equals(session.getWorkId()));
        saveSessions(sessions);
    }

    public void removeSessionsForWorks(Set<String> workIds) {
        if (workIds == null || workIds.isEmpty()) return;
        List<ProgressSession> sessions = getSessions();
        sessions.removeIf(session -> workIds.contains(session.getWorkId()));
        saveSessions(sessions);
    }

    public List<Reminder> getReminders() {
        List<Reminder> result = new ArrayList<>();
        String key = remindersKey();
        if (key == null) return result;
        String raw = prefs.getString(key, "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i = 0; i < a.length(); i++) {
                try {
                    JSONObject obj = a.optJSONObject(i);
                    if (obj == null) continue;
                    result.add(Reminder.fromJson(obj));
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
        return result;
    }

    public void saveReminders(List<Reminder> reminders) {
        JSONArray a = new JSONArray();
        if (reminders != null) {
            for (Reminder r : reminders) {
                if (r == null) continue;
                try { a.put(r.toJson()); } catch (Exception ignored) { }
            }
        }
        String key = remindersKey();
        if (key != null) prefs.edit().putString(key, a.toString()).apply();
    }

    public void saveStopwatchState(String workId, long accumulatedMillis, long startedAtMillis, boolean running) {
        prefs.edit()
                .putString(profileStateKey(KEY_STOPWATCH_WORK), workId == null ? "" : workId)
                .putLong(profileStateKey(KEY_STOPWATCH_ACCUMULATED), Math.max(0L, accumulatedMillis))
                .putLong(profileStateKey(KEY_STOPWATCH_STARTED), Math.max(0L, startedAtMillis))
                .putBoolean(profileStateKey(KEY_STOPWATCH_RUNNING), running)
                .apply();
    }

    public String getStopwatchWorkId() { return prefs.getString(profileStateKey(KEY_STOPWATCH_WORK), ""); }
    public long getStopwatchAccumulatedMillis() { return Math.max(0L, prefs.getLong(profileStateKey(KEY_STOPWATCH_ACCUMULATED), 0L)); }
    public long getStopwatchStartedAtMillis() { return Math.max(0L, prefs.getLong(profileStateKey(KEY_STOPWATCH_STARTED), 0L)); }
    public boolean isStopwatchRunning() { return prefs.getBoolean(profileStateKey(KEY_STOPWATCH_RUNNING), false); }
    public void clearStopwatchState() {
        prefs.edit().remove(profileStateKey(KEY_STOPWATCH_WORK)).remove(profileStateKey(KEY_STOPWATCH_ACCUMULATED)).remove(profileStateKey(KEY_STOPWATCH_STARTED)).remove(profileStateKey(KEY_STOPWATCH_RUNNING)).apply();
    }

    public void saveTimerState(long durationMillis, long remainingMillis, long startedAtMillis, boolean running) {
        prefs.edit()
                .putLong(profileStateKey(KEY_TIMER_DURATION), Math.max(0L, durationMillis))
                .putLong(profileStateKey(KEY_TIMER_REMAINING), Math.max(0L, remainingMillis))
                .putLong(profileStateKey(KEY_TIMER_STARTED), Math.max(0L, startedAtMillis))
                .putBoolean(profileStateKey(KEY_TIMER_RUNNING), running)
                .apply();
    }

    public long getTimerDurationMillis() { return Math.max(0L, prefs.getLong(profileStateKey(KEY_TIMER_DURATION), 0L)); }
    public long getTimerRemainingMillis() { return Math.max(0L, prefs.getLong(profileStateKey(KEY_TIMER_REMAINING), 0L)); }
    public long getTimerStartedAtMillis() { return Math.max(0L, prefs.getLong(profileStateKey(KEY_TIMER_STARTED), 0L)); }
    public boolean isTimerRunning() { return prefs.getBoolean(profileStateKey(KEY_TIMER_RUNNING), false); }
    public void clearTimerState() {
        prefs.edit().remove(profileStateKey(KEY_TIMER_DURATION)).remove(profileStateKey(KEY_TIMER_REMAINING)).remove(profileStateKey(KEY_TIMER_STARTED)).remove(profileStateKey(KEY_TIMER_RUNNING)).apply();
    }

    public void clearStudyData() {
        if (isGuestMode()) {
            prefs.edit().remove(KEY_GUEST_WORKS).remove(KEY_GUEST_SESSIONS).remove(KEY_GUEST_REMINDERS).apply();
        } else if (isAccountMode()) {
            prefs.edit().remove(KEY_WORKS).remove(KEY_SESSIONS).remove(KEY_REMINDERS).apply();
        }
    }
}
