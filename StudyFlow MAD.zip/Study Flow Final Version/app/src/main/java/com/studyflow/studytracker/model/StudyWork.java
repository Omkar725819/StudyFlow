package com.studyflow.studytracker.model;

import org.json.JSONException;
import org.json.JSONObject;
import java.util.UUID;

public class StudyWork {
    public enum Type { SUBJECT, TASK }

    private final String id;
    private String name;
    private Type type;
    private String semester;
    private String education;
    private String subjectId;
    private long dailyMillis;
    private long weeklyMillis;
    private long monthlyMillis;
    private long totalMillis;
    private long targetMillis;

    public StudyWork(Type type, String name) { this(UUID.randomUUID().toString(), type, name); }
    public StudyWork(String id, Type type, String name) {
        this.id = id == null || id.trim().isEmpty() ? UUID.randomUUID().toString() : id;
        this.type = type == null ? Type.TASK : type;
        this.name = name == null ? "" : name;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name == null ? "" : name; }
    public Type getType() { return type; }
    public void setType(Type type) { this.type = type == null ? Type.TASK : type; }
    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }
    public String getEducation() { return education; }
    public void setEducation(String education) { this.education = education; }
    public String getSubjectId() { return subjectId; }
    public void setSubjectId(String subjectId) { this.subjectId = subjectId; }
    public long getDailyMillis() { return dailyMillis; }
    public long getWeeklyMillis() { return weeklyMillis; }
    public long getMonthlyMillis() { return monthlyMillis; }
    public long getTotalMillis() { return totalMillis; }
    public long getTargetMillis() { return targetMillis; }
    public void setPeriodMillis(long daily, long weekly, long monthly) {
        dailyMillis = Math.max(0L, daily); weeklyMillis = Math.max(0L, weekly); monthlyMillis = Math.max(0L, monthly);
    }
    public void setTargetMillis(long targetMillis) { this.targetMillis = Math.max(0L, targetMillis); }

    public void addProgress(long millis) {
        if (millis <= 0L) return;
        dailyMillis += millis; weeklyMillis += millis; monthlyMillis += millis; totalMillis += millis;
    }
    public void resetProgress() { dailyMillis = weeklyMillis = monthlyMillis = totalMillis = 0L; }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id); o.put("name", name); o.put("type", type.name());
        o.put("semester", semester == null ? "" : semester);
        o.put("education", education == null ? "" : education);
        o.put("subjectId", subjectId == null ? "" : subjectId);
        o.put("dailyMillis", Math.max(0L, dailyMillis));
        o.put("weeklyMillis", Math.max(0L, weeklyMillis));
        o.put("monthlyMillis", Math.max(0L, monthlyMillis));
        o.put("totalMillis", Math.max(0L, totalMillis));
        o.put("targetMillis", Math.max(0L, targetMillis));
        return o;
    }

    /** Returns null for malformed persisted records so one bad row cannot crash startup. */
    public static StudyWork fromJson(JSONObject o) {
        if (o == null) return null;
        String id = o.optString("id", "").trim();
        String name = o.optString("name", "");
        if (id.isEmpty() || name.trim().isEmpty()) return null;
        Type type;
        try { type = Type.valueOf(o.optString("type", "TASK").trim().toUpperCase(java.util.Locale.ROOT)); }
        catch (Exception ignored) { return null; }
        StudyWork w = new StudyWork(id, type, name);
        w.semester = o.optString("semester", "");
        w.education = o.optString("education", "");
        w.subjectId = o.optString("subjectId", "");
        w.dailyMillis = Math.max(0L, o.optLong("dailyMillis", 0L));
        w.weeklyMillis = Math.max(0L, o.optLong("weeklyMillis", 0L));
        w.monthlyMillis = Math.max(0L, o.optLong("monthlyMillis", 0L));
        w.totalMillis = Math.max(0L, o.optLong("totalMillis", 0L));
        w.targetMillis = Math.max(0L, o.optLong("targetMillis", 0L));
        return w;
    }
}
