package com.studyflow.studytracker.ui;

import android.app.AlertDialog;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.studyflow.studytracker.R;
import com.studyflow.studytracker.model.Reminder;
import com.studyflow.studytracker.util.TimeFormatter;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class RemindersActivity extends BaseActivity {
    private LinearLayout list;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_reminders);
        bindBottomNav(getWindow().getDecorView());
        list = findViewById(R.id.reminders_list);
        findViewById(R.id.reminders_back).setOnClickListener(v -> finish());
        refresh();
    }

    private void refresh() {
        if (list == null) return;
        list.removeAllViews();
        List<Reminder> items = backend.reminders().getReminders();
        if (items.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No reminders scheduled");
            empty.setPadding(dp(20), dp(20), dp(20), dp(20));
            empty.setTextColor(getColor(R.color.sf_text_secondary));
            empty.setGravity(Gravity.CENTER);
            list.addView(empty);
        } else {
            for (int i = 0; i < items.size(); i++) {
                addRow(list, items.get(i), i < items.size() - 1);
            }
        }
    }

    private void addRow(ViewGroup container, Reminder r, boolean showLine) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(16), dp(16), dp(16), dp(16));
        row.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout textLayout = new LinearLayout(this);
        textLayout.setOrientation(LinearLayout.VERTICAL);
        textLayout.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        textLayout.setPadding(0, 0, dp(12), 0);

        boolean isPast = r.getTriggerAtMillis() < System.currentTimeMillis();

        TextView name = new TextView(this);
        name.setText(r.getName());
        name.setTextColor(getColor(isPast ? R.color.sf_text_tertiary : R.color.sf_text));
        name.setTextSize(16);
        name.setTypeface(null, Typeface.BOLD);
        if (isPast) {
            name.setPaintFlags(name.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        }

        TextView time = new TextView(this);
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault());
        time.setText(sdf.format(new Date(r.getTriggerAtMillis())));
        time.setTextColor(getColor(isPast ? R.color.sf_text_tertiary : R.color.sf_text_secondary));
        time.setTextSize(12);
        time.setPadding(0, dp(2), 0, 0);

        textLayout.addView(name);
        textLayout.addView(time);

        ImageView edit = new ImageView(this);
        edit.setImageResource(R.drawable.ic_edit);
        edit.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
        edit.setPadding(dp(8), dp(8), dp(8), dp(8));
        edit.setOnClickListener(v -> editReminder(r));
        if (isPast) edit.setAlpha(0.5f);

        ImageView delete = new ImageView(this);
        delete.setImageResource(R.drawable.ic_delete);
        delete.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
        delete.setPadding(dp(8), dp(8), dp(8), dp(8));
        delete.setOnClickListener(v -> confirmDelete(r));

        row.addView(textLayout);
        row.addView(edit);
        row.addView(delete);

        container.addView(row);
        if (showLine) {
            View line = new View(this);
            line.setBackgroundColor(getColor(R.color.sf_outline));
            container.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
        }
    }

    private void editReminder(Reminder r) {
        final EditText input = new EditText(this);
        input.setText(r.getName());
        input.setPadding(dp(20), dp(20), dp(20), dp(20));
        new AlertDialog.Builder(this)
            .setTitle("Edit Reminder")
            .setView(input)
            .setPositiveButton("Save", (d, w) -> {
                String newName = input.getText().toString().trim();
                if (!newName.isEmpty()) {
                    backend.reminders().updateReminderName(r.getId(), newName);
                    refresh();
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void confirmDelete(Reminder r) {
        new AlertDialog.Builder(this)
            .setTitle("Delete Reminder")
            .setMessage("Do you really want to delete this reminder?")
            .setPositiveButton("Delete", (d, w) -> {
                backend.reminders().deleteReminder(r.getId());
                refresh();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }
}
