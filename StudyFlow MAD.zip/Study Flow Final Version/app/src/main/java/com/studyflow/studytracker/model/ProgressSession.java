package com.studyflow.studytracker.model;

import org.json.JSONException;
import org.json.JSONObject;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.UUID;

public class ProgressSession {
    private final String id;
    private final String workId;
    private final String workName;
    private final StudyWork.Type type;
    private final long durationMillis;
    private final long timestampMillis;
    private final LocalDate date;

    public ProgressSession(String workId, String workName, StudyWork.Type type, long durationMillis, long timestampMillis) {
        this(UUID.randomUUID().toString(), workId, workName, type, durationMillis, timestampMillis);
    }

    private ProgressSession(String id, String workId, String workName, StudyWork.Type type, long durationMillis, long timestampMillis) {
        this.id = id == null || id.trim().isEmpty() ? UUID.randomUUID().toString() : id;
        this.workId = workId == null ? "" : workId;
        this.workName = workName == null ? "" : workName;
        this.type = type == null ? StudyWork.Type.TASK : type;
        this.durationMillis = Math.max(0L, durationMillis);
        this.timestampMillis = timestampMillis;
        this.date = Instant.ofEpochMilli(timestampMillis).atZone(ZoneId.systemDefault()).toLocalDate();
    }

    public String getId() { return id; }
    public String getWorkId() { return workId; }
    public String getWorkName() { return workName; }
    public StudyWork.Type getType() { return type; }
    public long getDurationMillis() { return durationMillis; }
    public long getTimestampMillis() { return timestampMillis; }
    public LocalDate getDate() { return date; }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id); o.put("workId", workId); o.put("workName", workName); o.put("type", type.name());
        o.put("durationMillis", durationMillis); o.put("timestampMillis", timestampMillis);
        return o;
    }

    /** Returns null for malformed persisted records so startup remains crash-safe. */
    public static ProgressSession fromJson(JSONObject o) {
        if (o == null) return null;
        String workId = o.optString("workId", "").trim();
        if (workId.isEmpty()) return null;
        StudyWork.Type type;
        try { type = StudyWork.Type.valueOf(o.optString("type", "TASK").trim().toUpperCase(java.util.Locale.ROOT)); }
        catch (Exception ignored) { return null; }
        return new ProgressSession(
                o.optString("id", UUID.randomUUID().toString()),
                workId,
                o.optString("workName", ""),
                type,
                Math.max(0L, o.optLong("durationMillis", 0L)),
                o.optLong("timestampMillis", System.currentTimeMillis())
        );
    }
}
