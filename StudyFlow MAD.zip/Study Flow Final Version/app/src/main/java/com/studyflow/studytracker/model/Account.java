package com.studyflow.studytracker.model;

import org.json.JSONException;
import org.json.JSONObject;

public class Account {
    private String username;
    private String email;
    private String mobileNumber;
    private String passwordHash;
    private String securityPin;
    private String profession;
    private String education;
    private String college;

    public Account() { }

    public Account(String username, String email, String mobileNumber, String password,
                   String securityPin, String profession, String education, String college) {
        this.username = username;
        this.email = email;
        this.mobileNumber = mobileNumber;
        this.passwordHash = password;
        this.securityPin = securityPin;
        this.profession = profession;
        this.education = education;
        this.college = college;
    }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getMobileNumber() { return mobileNumber; }
    public void setMobileNumber(String mobileNumber) { this.mobileNumber = mobileNumber; }
    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }
    public String getSecurityPin() { return securityPin; }
    public void setSecurityPin(String securityPin) { this.securityPin = securityPin; }
    public String getProfession() { return profession; }
    public void setProfession(String profession) { this.profession = profession; }
    public String getEducation() { return education; }
    public void setEducation(String education) { this.education = education; }
    public String getCollege() { return college; }
    public void setCollege(String college) { this.college = college; }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("username", username); o.put("email", email); o.put("mobileNumber", mobileNumber);
        o.put("passwordHash", passwordHash); o.put("securityPin", securityPin); o.put("profession", profession);
        o.put("education", education); o.put("college", college);
        return o;
    }

    public static Account fromJson(JSONObject o) {
        Account a = new Account();
        a.username = o.optString("username", "");
        a.email = o.optString("email", "");
        a.mobileNumber = o.optString("mobileNumber", "");
        a.passwordHash = o.optString("passwordHash", o.optString("password", ""));
        a.securityPin = o.optString("securityPin", "");
        a.profession = o.optString("profession", "");
        a.education = o.optString("education", "");
        a.college = o.optString("college", "");
        return a;
    }
}
