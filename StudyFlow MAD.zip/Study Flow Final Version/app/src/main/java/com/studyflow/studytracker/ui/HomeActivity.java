package com.studyflow.studytracker.ui;
import android.app.*; import android.os.*; import android.view.*; import android.widget.*; import java.time.*; import java.util.*; import com.studyflow.studytracker.R; import com.studyflow.studytracker.model.*; import com.studyflow.studytracker.util.TimeFormatter;
public class HomeActivity extends BaseActivity {
 private LinearLayout subjects,tasks; private TextView daily,weekly,monthly; 
 @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_home);bindBottomNav(getWindow().getDecorView());
  Account a=backend.accounts().getAccount(); TextView avatar=findViewById(R.id.top_avatar),title=findViewById(R.id.top_title),sub=findViewById(R.id.top_subtitle); if(backend.accounts().isGuest()){avatar.setText("G");title.setText("Guest Profile");}else{String username=a==null?"":a.getUsername()==null?"":a.getUsername().trim(); if(!username.isEmpty()){avatar.setText(username.substring(0,1).toUpperCase(Locale.ROOT));title.setText("Good to see you, "+username);}else{avatar.setText("G");title.setText("Study Flow");}} sub.setText("Track Every Second Of Your Life");
  daily=findViewById(R.id.daily_value);weekly=findViewById(R.id.weekly_value);monthly=findViewById(R.id.monthly_value); subjects=findViewById(R.id.subjects_list);tasks=findViewById(R.id.tasks_list);
  findViewById(R.id.daily_card).setOnClickListener(v->showProgress("Daily",LocalDate.now())); findViewById(R.id.weekly_card).setOnClickListener(v->showProgress("Weekly",LocalDate.now()));findViewById(R.id.monthly_card).setOnClickListener(v->showProgress("Monthly",LocalDate.now()));
  findViewById(R.id.filter_deck).setOnClickListener(v->showFilter()); refresh(); }
 @Override protected void onResume(){super.onResume();refresh();}
 private void refresh(){ if(daily==null||weekly==null||monthly==null||subjects==null||tasks==null)return; daily.setText(fmt(backend.progress().totalToday()));weekly.setText(fmt(backend.progress().totalWeek()));monthly.setText(fmt(backend.progress().totalMonth())); render(backend.work().getSubjects(),subjects);render(backend.work().getTasks(),tasks); boolean warning=false;for(StudyWork w:backend.work().getSubjects())if(w.getTargetMillis()>0&&backend.statistics().subjectTargetRemaining(w.getId())>0){warning=true;break;}View warningDeck=findViewById(R.id.warning_deck);if(warningDeck!=null)warningDeck.setVisibility(warning?View.VISIBLE:View.GONE);setAvatar();}
 private void setAvatar(){TextView avatar=findViewById(R.id.top_avatar);if(avatar==null)return;if(backend.accounts().isGuest()){avatar.setText("G");return;}Account a=backend.accounts().getAccount();String username=a==null?"":a.getUsername()==null?"":a.getUsername().trim();if(!username.isEmpty())avatar.setText(username.substring(0,1).toUpperCase(Locale.ROOT));}
 private void render(List<StudyWork> list,LinearLayout box){box.removeAllViews();for(StudyWork w:list){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setPadding(0,14,0,14);TextView n=new TextView(this);n.setText(w.getName());n.setTextColor(getColor(R.color.sf_text));n.setTextSize(15);n.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));TextView val=new TextView(this);val.setText(fmt(w.getDailyMillis()));val.setTextColor(getColor(R.color.sf_text_secondary));row.addView(n);row.addView(val);row.setOnClickListener(v->showProgressForWork(w));box.addView(row);View line=new View(this);line.setBackgroundColor(getColor(R.color.sf_outline));box.addView(line,new LinearLayout.LayoutParams(-1,1));}}
 private void showProgressForWork(StudyWork w){new AlertDialog.Builder(this).setTitle(w.getName()).setMessage("Daily  "+fmt(w.getDailyMillis())+"\nWeekly "+fmt(w.getWeeklyMillis())+"\nMonthly "+fmt(w.getMonthlyMillis())).setPositiveButton("OK",null).show();}
 private void showProgress(String period,LocalDate d){LinkedHashMap<String,Long> map=new LinkedHashMap<>();long total=0;if(period.equals("Daily")){map.putAll(backend.statistics().byWorkOnDate(d));total=backend.progress().totalForDate(d);}else if(period.equals("Monthly")){map.putAll(backend.statistics().byWorkInMonth(YearMonth.now()));total=backend.progress().totalMonth();}else{for(ProgressSession s:backend.progress().sessionsForDate(d)){} total=backend.progress().totalWeek();for(StudyWork w:backend.work().getAll())if(w.getWeeklyMillis()>0)map.put(w.getName(),w.getWeeklyMillis());}
  if(total<=0){new AlertDialog.Builder(this).setTitle(period+" Progress"+(period.equals("Daily")?" — "+d.toString():"")).setMessage("No Study Sessions").setPositiveButton("OK",null).show();return;}
  StringBuilder sb=new StringBuilder("Total ").append(fmt(total));for(Map.Entry<String,Long> e:map.entrySet())sb.append("\n\n").append(e.getKey()).append("  ").append(fmt(e.getValue()));new AlertDialog.Builder(this).setTitle(period+" Progress"+(period.equals("Daily")?" — "+d.toString():"")).setMessage(sb.toString()).setPositiveButton("OK",null).show();}
 private void showFilter(){
  final View v=getLayoutInflater().inflate(R.layout.dialog_filter,null,false);
  AlertDialog d=new AlertDialog.Builder(this).setView(v).create();
  CalendarView cal=v.findViewById(R.id.filter_calendar);
  TextView date=v.findViewById(R.id.filter_date),month=v.findViewById(R.id.filter_month),apply=v.findViewById(R.id.filter_apply);
  LinearLayout monthPicker=v.findViewById(R.id.filter_month_picker);
  Spinner monthSelector=v.findViewById(R.id.filter_month_selector),yearSelector=v.findViewById(R.id.filter_year_selector);
  String[] monthNames={"January","February","March","April","May","June","July","August","September","October","November","December"};
  monthSelector.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,monthNames));
  String[] years=new String[11]; int currentYear= Calendar.getInstance().get(Calendar.YEAR);
  for(int i=0;i<years.length;i++) years[i]=String.valueOf(currentYear-5+i);
  yearSelector.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,years));
  monthSelector.setSelection(Calendar.getInstance().get(Calendar.MONTH));
  yearSelector.setSelection(5);
  final boolean[] isDate={true};
  final LocalDate[] selectedDate={LocalDate.now()};
  Calendar todayCal= Calendar.getInstance();
  cal.setDate(todayCal.getTimeInMillis(), false, false);
  cal.setOnDateChangeListener((view, year, monthIndex, dayOfMonth)->selectedDate[0]=LocalDate.of(year, monthIndex+1, dayOfMonth));
  date.setOnClickListener(x->{isDate[0]=true;date.setBackgroundResource(R.drawable.bg_selected_pill);date.setTextColor(getColor(android.R.color.white));month.setBackgroundResource(R.drawable.bg_pill);month.setTextColor(getColor(R.color.sf_text_secondary));cal.setVisibility(View.VISIBLE);monthPicker.setVisibility(View.GONE);});
  month.setOnClickListener(x->{isDate[0]=false;month.setBackgroundResource(R.drawable.bg_selected_pill);month.setTextColor(getColor(android.R.color.white));date.setBackgroundResource(R.drawable.bg_pill);date.setTextColor(getColor(R.color.sf_text_secondary));cal.setVisibility(View.GONE);monthPicker.setVisibility(View.VISIBLE);});
  apply.setOnClickListener(x->{
    if(isDate[0]){showProgress("Daily", selectedDate[0]);}
    else{
      int monthIndex=monthSelector.getSelectedItemPosition()+1;
      int year=Integer.parseInt(String.valueOf(yearSelector.getSelectedItem()));
      YearMonth ym=YearMonth.of(year,monthIndex);
      LinkedHashMap<String,Long> m=new LinkedHashMap<>(backend.statistics().byWorkInMonth(ym));
      StringBuilder out=new StringBuilder();
      for(Map.Entry<String,Long> e:m.entrySet())out.append(e.getKey()).append("  ").append(fmt(e.getValue())).append("\n");
      new AlertDialog.Builder(this).setTitle(ym+" Progress").setMessage(out.length()==0?"No study sessions.":out.toString()).setPositiveButton("OK",null).show();
    }
    d.dismiss();
  });
  d.show();
 }
 private String fmt(long ms){return TimeFormatter.formatHms(ms);}
}
