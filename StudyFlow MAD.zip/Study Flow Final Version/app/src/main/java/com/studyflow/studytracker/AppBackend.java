package com.studyflow.studytracker;

import android.content.Context;
import com.studyflow.studytracker.data.LocalStore;
import com.studyflow.studytracker.service.AccountService;
import com.studyflow.studytracker.service.ProgressService;
import com.studyflow.studytracker.service.ProgressRolloverService;
import com.studyflow.studytracker.service.ReminderService;
import com.studyflow.studytracker.service.StatisticsService;
import com.studyflow.studytracker.service.StopwatchService;
import com.studyflow.studytracker.service.StudyWorkService;
import com.studyflow.studytracker.service.TimerService;

/** Composition root for Phase 2. UI integration belongs to Phase 3. */
public final class AppBackend {
    private final LocalStore store;
    private final AccountService accountService;
    private final StudyWorkService studyWorkService;
    private final ProgressService progressService;
    private final StatisticsService statisticsService;
    private final ReminderService reminderService;
    private final StopwatchService stopwatchService;
    private final TimerService timerService;

    public AppBackend(Context context) {
        store = new LocalStore(context);
        accountService = new AccountService(store);
        studyWorkService = new StudyWorkService(store);
        progressService = new ProgressService(store);
        try { new ProgressRolloverService(store).reconcile(); } catch (RuntimeException ignored) { /* corrupted legacy progress must never crash app startup */ }
        statisticsService = new StatisticsService(store);
        reminderService = new ReminderService(context, store);
        stopwatchService = new StopwatchService(store);
        timerService = new TimerService(store);
    }

    public LocalStore store() { return store; }
    public AccountService accounts() { return accountService; }
    public StudyWorkService work() { return studyWorkService; }
    public ProgressService progress() { return progressService; }
    public StatisticsService statistics() { return statisticsService; }
    public ReminderService reminders() { return reminderService; }
    public StopwatchService stopwatch() { return stopwatchService; }
    public TimerService timer() { return timerService; }
}
