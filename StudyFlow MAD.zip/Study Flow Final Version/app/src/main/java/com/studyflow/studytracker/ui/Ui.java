package com.studyflow.studytracker.ui;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import com.studyflow.studytracker.R;

public final class Ui {
    private Ui() {}
    public static AlertDialog dialog(Context c, int layout) {
        View v=LayoutInflater.from(c).inflate(layout,null,false);
        AlertDialog d=new AlertDialog.Builder(c).setView(v).create();
        d.setOnShowListener(x->{ Window w=d.getWindow(); if(w!=null){w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));} });
        return d;
    }
    public static void error(TextView label,String msg){ label.setText(msg); label.setVisibility(View.VISIBLE); }
}
