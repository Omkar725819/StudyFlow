package com.studyflow.studytracker.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import com.studyflow.studytracker.R;

public class LoginActivity extends BaseActivity {
 @Override protected void onCreate(Bundle b){super.onCreate(b); if(backend.accounts().isGuest() || backend.accounts().isAccountSession()){ go(HomeActivity.class); return; } setContentView(R.layout.activity_login);
  EditText id=findViewById(R.id.login_identifier), pass=findViewById(R.id.login_password); TextView err=findViewById(R.id.login_error);
  findViewById(R.id.login_button).setOnClickListener(v->{String i=id.getText().toString().trim(),p=pass.getText().toString(); if(backend.accounts().authenticate(i,p)){err.setVisibility(View.GONE); go(HomeActivity.class);} else Ui.error(err,"Invalid Username or Password");});
  findViewById(R.id.continue_guest).setOnClickListener(v->{backend.accounts().loginAsGuest(); go(HomeActivity.class);});
  findViewById(R.id.create_account).setOnClickListener(v->startActivity(new android.content.Intent(this,CreateAccountActivity.class)));
  findViewById(R.id.forgot_password).setOnClickListener(v->startActivity(new android.content.Intent(this,ForgotPasswordActivity.class)));
 }
}
