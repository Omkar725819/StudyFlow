package com.studyflow.studytracker.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.graphics.Rect;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.studyflow.studytracker.AppBackend;
import com.studyflow.studytracker.R;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public abstract class BaseActivity extends AppCompatActivity {
    protected AppBackend backend;
    private static final int PRESS_DURATION = 90;
    private static final int RELEASE_DURATION = 180;
    private boolean notificationPermissionRequested;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        backend = new AppBackend(getApplicationContext());
        getDelegate().setLocalNightMode(backend.store().isDarkMode()
                ? AppCompatDelegate.MODE_NIGHT_YES
                : AppCompatDelegate.MODE_NIGHT_NO);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }

    @Override public void startActivity(Intent intent) {
        super.startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    @Override protected void onPostCreate(Bundle state) {
        super.onPostCreate(state);
        View content = getWindow().getDecorView();
        attachPremiumPressAnimations(content);
        attachKeyboardAwareScrolling(content);
        animatePageEntry(content);
        hideStatusBar();
        if (!(this instanceof LoginActivity) && !(this instanceof CreateAccountActivity) && !(this instanceof ForgotUsernameActivity) && !(this instanceof ForgotPasswordActivity)) {
            content.postDelayed(this::requestNotificationPermissionIfNeeded, 350);
        }
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideStatusBar();
    }

    private void hideStatusBar() {
        View decor = getWindow().peekDecorView();
        if (decor == null) return;
        WindowInsetsController controller = getWindow().getInsetsController();
        if (controller != null) {
            controller.hide(WindowInsets.Type.statusBars());
            controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        }
    }


    private void attachKeyboardAwareScrolling(View view) {
        if (view instanceof EditText) {
            view.setOnFocusChangeListener((v, hasFocus) -> {
                if (hasFocus) {
                    v.postDelayed(() -> {
                        Rect rect = new Rect(0, 0, v.getWidth(), v.getHeight());
                        v.requestRectangleOnScreen(rect, true);
                    }, 220);
                }
            });
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                attachKeyboardAwareScrolling(group.getChildAt(i));
            }
        }
    }

    private void animatePageEntry(View root) {
        View content = findViewById(android.R.id.content);
        if (!(content instanceof ViewGroup)) return;
        ViewGroup group = (ViewGroup) content;
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            child.setAlpha(0f);
            child.setScaleX(0.985f);
            child.setScaleY(0.985f);
            child.animate()
                    .alpha(1f).scaleX(1f).scaleY(1f)
                    .setStartDelay(Math.min(i * 22L, 66L))
                    .setDuration(300)
                    .setInterpolator(new AccelerateDecelerateInterpolator())
                    .start();
        }
    }

    private void attachPremiumPressAnimations(View view) {
        if (view == null) return;
        if (isInteractionView(view)) {
            view.setOnTouchListener((v, event) -> {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        v.animate().scaleX(0.975f).scaleY(0.975f)
                                .setDuration(PRESS_DURATION)
                                .setInterpolator(new AccelerateDecelerateInterpolator())
                                .start();
                        break;
                    case MotionEvent.ACTION_UP:
                        v.animate().scaleX(1f).scaleY(1f)
                                .setDuration(RELEASE_DURATION)
                                .setInterpolator(new OvershootInterpolator(0.55f))
                                .start();
                        v.postDelayed(() -> v.performClick(), 0);
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(1f).scaleY(1f)
                                .setDuration(120)
                                .setInterpolator(new AccelerateDecelerateInterpolator())
                                .start();
                        return true;
                }
                return true;
            });
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                attachPremiumPressAnimations(group.getChildAt(i));
            }
        }
    }

    private boolean isInteractionView(View view) {
        // Compound buttons (especially Switch) need their native touch handling
        // so their checked state changes normally. All other clickable controls
        // receive the shared premium press/release animation.
        if (view instanceof EditText || view instanceof CompoundButton) return false;
        return view.isClickable() || view.isLongClickable();
    }

    protected void animateVisibility(View view, boolean show) {
        if (view == null) return;
        view.animate().cancel();
        if (show) {
            view.setVisibility(View.VISIBLE);
            view.setAlpha(0f);
            view.setScaleY(0.96f);
            view.animate().alpha(1f).scaleY(1f)
                    .setDuration(240)
                    .setInterpolator(new OvershootInterpolator(0.3f))
                    .start();
        } else {
            view.animate().alpha(0f).scaleY(0.96f)
                    .setDuration(160)
                    .setInterpolator(new AccelerateDecelerateInterpolator())
                    .withEndAction(() -> {
                        view.setVisibility(View.GONE);
                        view.setAlpha(1f);
                        view.setScaleY(1f);
                    }).start();
        }
    }

    protected void animateSelection(View active, View inactive) {
        if (active != null) {
            active.animate().cancel();
            active.setAlpha(0.72f);
            active.setScaleX(0.97f);
            active.setScaleY(0.97f);
            active.animate().alpha(1f).scaleX(1f).scaleY(1f)
                    .setDuration(220)
                    .setInterpolator(new OvershootInterpolator(0.35f))
                    .start();
        }
        if (inactive != null) {
            inactive.animate().cancel();
            inactive.setAlpha(1f);
            inactive.setScaleX(1f);
            inactive.setScaleY(1f);
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (notificationPermissionRequested || isFinishing() || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
        notificationPermissionRequested = true;
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
        }
    }
    protected void bindBottomNav(View root) {
        View home=root.findViewById(R.id.nav_home), tasks=root.findViewById(R.id.nav_tasks), clock=root.findViewById(R.id.nav_clock), settings=root.findViewById(R.id.nav_settings);
        if(home!=null) home.setOnClickListener(v->go(HomeActivity.class));
        if(tasks!=null) tasks.setOnClickListener(v->go(TasksActivity.class));
        if(clock!=null) clock.setOnClickListener(v->go(ClockActivity.class));
        if(settings!=null) settings.setOnClickListener(v->go(SettingsActivity.class));
        View avatar=root.findViewById(R.id.top_avatar); if(avatar!=null) avatar.setOnClickListener(v->go(SettingsActivity.class));

        View navBar = root.findViewById(R.id.bottom_navigation);
        if (navBar != null) {
            ViewGroup.LayoutParams raw = navBar.getLayoutParams();
            if (raw instanceof ViewGroup.MarginLayoutParams) {
                ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) raw;
                lp.bottomMargin = 0;
                lp.height = dp(84);
                navBar.setLayoutParams(lp);
                navBar.setPadding(navBar.getPaddingLeft(), navBar.getPaddingTop(), navBar.getPaddingRight(), navBar.getPaddingBottom() + dp(10));
            }
        }

        View selected = null;
        if (this instanceof HomeActivity) selected = home;
        else if (this instanceof TasksActivity) selected = tasks;
        else if (this instanceof ClockActivity) selected = clock;
        else if (this instanceof SettingsActivity) selected = settings;
        if (selected != null) selected.setBackgroundResource(R.drawable.bg_nav_selected);
    }
    protected void go(Class<?> target) { Intent i=new Intent(this,target); startActivity(i); finish(); }
    protected int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}
    protected void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
    protected String text(int id){ TextView v=findViewById(id); return v==null?"":v.getText().toString().trim(); }
}
