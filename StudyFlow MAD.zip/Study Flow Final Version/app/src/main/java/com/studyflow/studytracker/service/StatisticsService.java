package com.studyflow.studytracker.service;

import com.studyflow.studytracker.data.LocalStore;
import com.studyflow.studytracker.model.ProgressSession;
import com.studyflow.studytracker.model.StudyWork;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class StatisticsService {
    private final LocalStore store;
    public StatisticsService(LocalStore store) { this.store = store; }

    public Map<String, Long> byWorkOnDate(LocalDate date) { return aggregate(new ProgressService(store).sessionsForDate(date)); }
    public Map<String, Long> byWorkInMonth(YearMonth month) { return aggregate(new ProgressService(store).sessionsForMonth(month)); }

    public Map<String, Long> byWorkToday() { return byWorkOnDate(LocalDate.now()); }

    public long subjectTargetRemaining(String subjectId) {
        for (StudyWork w : store.getWorks()) if (w.getId().equals(subjectId) && w.getType() == StudyWork.Type.SUBJECT) return Math.max(0L, w.getTargetMillis() - w.getDailyMillis());
        return 0L;
    }

    private Map<String, Long> aggregate(List<ProgressSession> sessions) {
        Map<String, Long> result = new LinkedHashMap<>();
        for (ProgressSession s : sessions) result.put(s.getWorkName(), result.getOrDefault(s.getWorkName(), 0L) + s.getDurationMillis());
        return result;
    }
}
