package com.studyflow.studytracker.util;

public final class TimeFormatter {
    private TimeFormatter() { }
    public static String formatHms(long millis) {
        long totalSeconds = Math.max(0L, millis) / 1000L;
        long h = totalSeconds / 3600L; long m = (totalSeconds % 3600L) / 60L; long s = totalSeconds % 60L;
        return String.format(java.util.Locale.getDefault(), "%02d:%02d:%02d", h, m, s);
    }
}
