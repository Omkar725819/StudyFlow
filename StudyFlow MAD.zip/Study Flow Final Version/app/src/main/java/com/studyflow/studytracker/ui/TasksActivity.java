package com.studyflow.studytracker.ui;

import android.app.AlertDialog;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import com.studyflow.studytracker.R;
import com.studyflow.studytracker.model.Account;
import com.studyflow.studytracker.model.StudyWork;
import com.studyflow.studytracker.util.TimeFormatter;
import java.util.List;

public class TasksActivity extends BaseActivity {
    private LinearLayout list;
    private boolean subjectMode = true;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_tasks);
        bindBottomNav(getWindow().getDecorView());
        View placeholder = findViewById(R.id.subject_card_1);
        list = placeholder != null && placeholder.getParent() instanceof LinearLayout
                ? (LinearLayout) placeholder.getParent() : null;
        findViewById(R.id.subjects_tab).setOnClickListener(v -> { subjectMode = true; updateSegmentSelection(); refresh(); });
        findViewById(R.id.tasks_tab).setOnClickListener(v -> { subjectMode = false; updateSegmentSelection(); refresh(); });
        updateSegmentSelection();
        findViewById(R.id.add_fab).setOnClickListener(v -> chooseAdd());
        refresh();
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private void refresh() {
        if (list == null) return;
        list.removeAllViews();
        List<StudyWork> items = subjectMode ? backend.work().getSubjects() : backend.work().getTasks();
        for (StudyWork w : items) addRow(list, w);
    }

    private void addRow(ViewGroup container, StudyWork w) {
        int pad = dp(18);
        int iconSize = dp(46);
        int spacing = dp(10);

        FrameLayout card = new FrameLayout(this);
        card.setPadding(pad, pad, pad, pad);
        card.setBackgroundResource(R.drawable.bg_surface);
        card.setClickable(true);
        card.setFocusable(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.TOP | Gravity.CENTER_VERTICAL);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setGravity(Gravity.TOP);

        TextView name = new TextView(this);
        name.setText(nullToEmpty(w.getName()));
        name.setTextSize(21);
        name.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        name.setTextColor(getColor(R.color.sf_text));
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);

        TextView meta = new TextView(this);
        meta.setText(subjectMode
                ? formatSemester(w.getSemester())
                : taskMeta(w));
        meta.setTextColor(getColor(R.color.sf_text));
        meta.setTextSize(14);
        meta.setSingleLine(true);
        meta.setEllipsize(android.text.TextUtils.TruncateAt.END);

        info.addView(name, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams metaLp = new LinearLayout.LayoutParams(-1, -2);
        metaLp.topMargin = dp(6);
        info.addView(meta, metaLp);

        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(0, -2, 1f);
        infoLp.rightMargin = dp(10);
        topRow.addView(info, infoLp);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);

        ImageButton edit = iconButton(R.drawable.ic_edit, getColor(R.color.sf_text), false, "Edit");
        ImageButton start = iconButton(R.drawable.ic_play, getColor(R.color.sf_primary), false, "Start Work");
        ImageButton del = iconButton(R.drawable.ic_delete, getColor(R.color.sf_danger), true, "Delete");

        actions.addView(edit, new LinearLayout.LayoutParams(iconSize, iconSize));
        LinearLayout.LayoutParams startLp = new LinearLayout.LayoutParams(iconSize, iconSize);
        startLp.leftMargin = spacing;
        actions.addView(start, startLp);
        LinearLayout.LayoutParams delLp = new LinearLayout.LayoutParams(iconSize, iconSize);
        delLp.leftMargin = spacing;
        actions.addView(del, delLp);

        topRow.addView(actions, new LinearLayout.LayoutParams(-2, iconSize));
        content.addView(topRow, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout dailyRow = new LinearLayout(this);
        dailyRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams dailyRowLp = new LinearLayout.LayoutParams(-1, -2);
        dailyRowLp.topMargin = dp(18);
        content.addView(dailyRow, dailyRowLp);

        TextView dailyLabel = new TextView(this);
        dailyLabel.setText("Daily");
        dailyLabel.setTextSize(14);
        dailyLabel.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        dailyLabel.setTextColor(getColor(R.color.sf_text));
        dailyRow.addView(dailyLabel, new LinearLayout.LayoutParams(dp(58), dp(32)));

        TextView daily = new TextView(this);
        daily.setText(fmt(w.getDailyMillis()));
        daily.setTextSize(28);
        daily.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        daily.setTextColor(getColor(R.color.sf_text));
        dailyRow.addView(daily, new LinearLayout.LayoutParams(0, dp(38), 1f));

        content.setPadding(0, 0, dp(36), 0);
        card.addView(content, new FrameLayout.LayoutParams(-1, -2));

        TextView chevron = new TextView(this);
        chevron.setText("›");
        chevron.setTextSize(40);
        chevron.setTextColor(getColor(R.color.sf_text_secondary));
        chevron.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams chevronLp = new FrameLayout.LayoutParams(dp(30), dp(40), Gravity.CENTER_VERTICAL | Gravity.END);
        card.addView(chevron, chevronLp);

        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
        cardLp.bottomMargin = dp(12);
        container.addView(card, cardLp);

        View.OnClickListener startListener = v -> {
            ClockActivity.selectedWorkId = w.getId();
            go(ClockActivity.class);
        };
        edit.setOnClickListener(v -> editWork(w));
        del.setOnClickListener(v -> confirmDelete(w));
        start.setOnClickListener(startListener);
        card.setOnClickListener(v -> startListener.onClick(v));
    }

    private ImageButton iconButton(int iconRes, int iconColor, boolean danger, String description) {
        ImageButton button = new ImageButton(this);
        button.setImageResource(iconRes);
        button.setContentDescription(description);
        button.setScaleType(android.widget.ImageView.ScaleType.CENTER_INSIDE);
        button.setPadding(dp(11), dp(11), dp(11), dp(11));
        button.setColorFilter(iconColor);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        int fill = getColor(R.color.sf_surface_alt);
        bg.setColor(fill);
        bg.setStroke(dp(1), getColor(R.color.sf_outline));
        button.setBackground(bg);
        return button;
    }


    private void updateSegmentSelection() {
        TextView subjectsTab = findViewById(R.id.subjects_tab);
        TextView tasksTab = findViewById(R.id.tasks_tab);
        if (subjectMode) {
            subjectsTab.setBackgroundResource(R.drawable.bg_selected_pill);
            subjectsTab.setTextColor(getColor(android.R.color.white));
            subjectsTab.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
            tasksTab.setBackgroundResource(R.drawable.bg_pill);
            tasksTab.setTextColor(getColor(R.color.sf_text_secondary));
            tasksTab.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.NORMAL);
            animateSelection(subjectsTab, tasksTab);
        } else {
            tasksTab.setBackgroundResource(R.drawable.bg_selected_pill);
            tasksTab.setTextColor(getColor(android.R.color.white));
            tasksTab.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
            subjectsTab.setBackgroundResource(R.drawable.bg_pill);
            subjectsTab.setTextColor(getColor(R.color.sf_text_secondary));
            subjectsTab.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.NORMAL);
            animateSelection(tasksTab, subjectsTab);
        }
    }
    private void chooseAdd() {
        new AlertDialog.Builder(this).setTitle("Add")
                .setItems(new String[]{"Subject", "Task"}, (d, which) -> { if (which == 0) addSubject(); else addTask(); }).show();
    }

    private void addSubject() {
        View v = getLayoutInflater().inflate(R.layout.dialog_add_subject, null, false);
        AlertDialog d = new AlertDialog.Builder(this).setView(v).create();
        EditText name = v.findViewById(R.id.add_subject_name);
        EditText edu = v.findViewById(R.id.add_subject_education);
        Account a = backend.accounts().getAccount();
        if (a != null && !backend.accounts().isGuest()) edu.setText(a.getEducation());
        v.findViewById(R.id.add_subject_cancel).setOnClickListener(x -> d.dismiss());
        v.findViewById(R.id.add_subject_save).setOnClickListener(x -> {
            try {
                Spinner semester = v.findViewById(R.id.add_subject_semester);
                backend.work().addSubject(name.getText().toString(), semester.getSelectedItem().toString(), edu.getText().toString());
                d.dismiss(); refresh();
            } catch (Exception e) { toast(e.getMessage()); }
        });
        d.show();
    }

    private void addTask() {
        View v = getLayoutInflater().inflate(R.layout.dialog_add_task, null, false);
        AlertDialog d = new AlertDialog.Builder(this).setView(v).create();
        v.findViewById(R.id.add_task_cancel).setOnClickListener(x -> d.dismiss());
        v.findViewById(R.id.add_task_save).setOnClickListener(x -> {
            try {
                EditText n = v.findViewById(R.id.add_task_name), s = v.findViewById(R.id.add_task_subject);
                backend.work().addTask(n.getText().toString(), findSubjectId(s.getText().toString()));
                d.dismiss(); refresh();
            } catch (Exception e) { toast(e.getMessage()); }
        });
        d.show();
    }

    private void editWork(StudyWork w) {
        if (w.getType() == StudyWork.Type.SUBJECT) {
            View v = getLayoutInflater().inflate(R.layout.dialog_edit_subject, null, false);
            AlertDialog d = new AlertDialog.Builder(this).setView(v).create();
            EditText name = v.findViewById(R.id.edit_subject_name);
            Spinner semester = v.findViewById(R.id.edit_subject_semester);
            EditText education = v.findViewById(R.id.edit_subject_education);
            name.setText(w.getName()); education.setText(nullToEmpty(w.getEducation()));
            selectSpinner(semester, w.getSemester());
            v.findViewById(R.id.edit_subject_cancel).setOnClickListener(x -> d.dismiss());
            v.findViewById(R.id.edit_subject_save).setOnClickListener(x -> {
                if (name.getText().toString().trim().isEmpty()) { toast("Subject name is required"); return; }
                w.setName(name.getText().toString().trim());
                w.setSemester(String.valueOf(semester.getSelectedItem()));
                w.setEducation(education.getText().toString().trim());
                backend.work().update(w); d.dismiss(); refresh();
            });
            d.show();
        } else {
            View v = getLayoutInflater().inflate(R.layout.dialog_edit_task, null, false);
            AlertDialog d = new AlertDialog.Builder(this).setView(v).create();
            EditText name = v.findViewById(R.id.edit_task_name), subject = v.findViewById(R.id.edit_task_subject);
            name.setText(w.getName()); subject.setText(subjectName(w.getSubjectId()));
            v.findViewById(R.id.edit_task_cancel).setOnClickListener(x -> d.dismiss());
            v.findViewById(R.id.edit_task_save).setOnClickListener(x -> {
                if (name.getText().toString().trim().isEmpty()) { toast("Task details are required"); return; }
                w.setName(name.getText().toString().trim()); w.setSubjectId(findSubjectId(subject.getText().toString()));
                backend.work().update(w); d.dismiss(); refresh();
            });
            d.show();
        }
    }

    private void confirmDelete(StudyWork w) {
        new AlertDialog.Builder(this).setTitle("Delete " + w.getName() + "?")
                .setMessage("You will lose your saved progress for this " + (w.getType() == StudyWork.Type.SUBJECT ? "subject" : "task") + ".")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (d, x) -> { backend.work().delete(w.getId()); refresh(); }).show();
    }

    private void confirmReset(StudyWork w) {
        new AlertDialog.Builder(this).setTitle("Reset Progress")
                .setMessage("You will lose your saved progress.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (d, x) -> { backend.work().resetProgress(w.getId()); refresh(); }).show();
    }

    private String findSubjectId(String name) {
        String target = name == null ? "" : name.trim();
        if (target.isEmpty()) return "";
        for (StudyWork subject : backend.work().getSubjects()) if (subject.getName().equalsIgnoreCase(target)) return subject.getId();
        return "";
    }

    private String subjectName(String id) {
        StudyWork subject = backend.work().find(id);
        return subject == null ? "" : subject.getName();
    }

    private String taskMeta(StudyWork w) {
        String subject = subjectName(w.getSubjectId());
        return subject.isEmpty() ? "Task" : subject;
    }

    private void selectSpinner(Spinner spinner, String value) {
        if (value == null) return;
        for (int i = 0; i < spinner.getCount(); i++) if (value.equals(spinner.getItemAtPosition(i).toString())) { spinner.setSelection(i); return; }
    }

    private String formatSemester(String value) {
        String semester = nullToEmpty(value).trim();
        if (semester.isEmpty()) return "Semester";
        return semester.regionMatches(true, 0, "Semester ", 0, 9)
                ? semester
                : "Semester " + semester;
    }

    private String nullToEmpty(String value) { return value == null ? "" : value; }
    private String fmt(long x) { return TimeFormatter.formatHms(x); }
}
