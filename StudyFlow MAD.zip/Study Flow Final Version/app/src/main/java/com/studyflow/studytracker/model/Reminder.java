package com.studyflow.studytracker.model;

import org.json.JSONException;
import org.json.JSONObject;
import java.util.UUID;

public class Reminder {
    private final String id;
    private String name;
    private long triggerAtMillis;
    private boolean enabled;

    public Reminder(String name, long triggerAtMillis) {
        this(UUID.randomUUID().toString(), name, triggerAtMillis, true);
    }

    public Reminder(String id, String name, long triggerAtMillis, boolean enabled) {
        this.id = id; this.name = name; this.triggerAtMillis = triggerAtMillis; this.enabled = enabled;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public long getTriggerAtMillis() { return triggerAtMillis; }
    public void setTriggerAtMillis(long triggerAtMillis) { this.triggerAtMillis = triggerAtMillis; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject(); o.put("id", id); o.put("name", name);
        o.put("triggerAtMillis", triggerAtMillis); o.put("enabled", enabled); return o;
    }

    public static Reminder fromJson(JSONObject o) {
        return new Reminder(o.optString("id", UUID.randomUUID().toString()), o.optString("name", ""),
                o.optLong("triggerAtMillis", 0L), o.optBoolean("enabled", true));
    }
}
