package com.studyflow.studytracker.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.studyflow.studytracker.AppBackend;

public final class ReminderBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        new AppBackend(context.getApplicationContext()).reminders().reschedulePendingReminders();
    }
}
