package com.studyflow.studytracker.service;

import com.studyflow.studytracker.data.LocalStore;

/** Timer state survives Activity recreation and process restarts until it finishes or is explicitly reset. */
public class TimerService {
    private final LocalStore store;
    private long durationMillis;
    private long remainingMillis;
    private long startedAtMillis;
    private boolean running;

    public TimerService(LocalStore store) {
        this.store = store;
        durationMillis = store.getTimerDurationMillis();
        remainingMillis = store.getTimerRemainingMillis();
        startedAtMillis = store.getTimerStartedAtMillis();
        running = store.isTimerRunning() && remainingMillis > 0L;
        if (running && startedAtMillis <= 0L) { running = false; persist(); }
        if (durationMillis > 0L && remainingMillis == 0L && !running) persist();
    }

    public void configure(long durationMillis) {
        if (durationMillis <= 0) throw new IllegalArgumentException("Timer duration must be positive");
        this.durationMillis = durationMillis; this.remainingMillis = durationMillis; this.startedAtMillis = 0L; this.running = false; persist();
    }

    public void start() {
        update();
        if (remainingMillis > 0 && !running) { startedAtMillis = System.currentTimeMillis(); running = true; persist(); }
    }

    public void pause() { update(); running = false; startedAtMillis = 0L; persist(); }
    public void resume() { start(); }
    public long getRemainingMillis() { update(); return remainingMillis; }
    public boolean isRunning() { update(); return running; }
    public boolean isFinished() { return getRemainingMillis() <= 0L; }

    public void reset() { remainingMillis = durationMillis; running = false; startedAtMillis = 0L; persist(); }

    private void update() {
        if (!running) return;
        long elapsed = Math.max(0L, System.currentTimeMillis() - startedAtMillis);
        remainingMillis = Math.max(0L, remainingMillis - elapsed);
        startedAtMillis = System.currentTimeMillis();
        if (remainingMillis == 0L) { running = false; startedAtMillis = 0L; persist(); }
    }

    private void persist() { store.saveTimerState(durationMillis, remainingMillis, startedAtMillis, running); }
}
