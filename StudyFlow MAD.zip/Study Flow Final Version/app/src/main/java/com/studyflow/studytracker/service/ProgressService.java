package com.studyflow.studytracker.service;

import com.studyflow.studytracker.data.LocalStore;
import com.studyflow.studytracker.model.ProgressSession;
import com.studyflow.studytracker.model.StudyWork;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;

public class ProgressService {
    private final LocalStore store;
    public ProgressService(LocalStore store) { this.store = store; }

    public void saveStopwatchProgress(String workId, long durationMillis) {
        if (durationMillis <= 0) return;
        List<StudyWork> works = store.getWorks(); StudyWork work = null;
        for (StudyWork w : works) if (w.getId().equals(workId)) { work = w; break; }
        if (work == null) throw new IllegalArgumentException("Work item not found");
        work.addProgress(durationMillis); store.saveWorks(works);
        List<ProgressSession> sessions = store.getSessions();
        sessions.add(new ProgressSession(work.getId(), work.getName(), work.getType(), durationMillis, System.currentTimeMillis()));
        store.saveSessions(sessions);
    }

    public List<ProgressSession> sessionsForDate(LocalDate date) {
        List<ProgressSession> result = new ArrayList<>(); for (ProgressSession s : store.getSessions()) if (s.getDate().equals(date)) result.add(s); return result;
    }

    public List<ProgressSession> sessionsForMonth(YearMonth month) {
        List<ProgressSession> result = new ArrayList<>(); for (ProgressSession s : store.getSessions()) if (YearMonth.from(s.getDate()).equals(month)) result.add(s); return result;
    }

    public long totalForDate(LocalDate date) { long total=0; for (ProgressSession s : sessionsForDate(date)) total += s.getDurationMillis(); return total; }
    public long totalForMonth(YearMonth month) { long total=0; for (ProgressSession s : sessionsForMonth(month)) total += s.getDurationMillis(); return total; }

    public long totalToday() { return totalForDate(LocalDate.now()); }
    public long totalWeek() {
        LocalDate today = LocalDate.now(); LocalDate start = today.minusDays(today.getDayOfWeek().getValue()-1L); long total=0;
        for (ProgressSession s : store.getSessions()) if (!s.getDate().isBefore(start) && !s.getDate().isAfter(today)) total += s.getDurationMillis(); return total;
    }
    public long totalMonth() { return totalForMonth(YearMonth.now()); }
}
