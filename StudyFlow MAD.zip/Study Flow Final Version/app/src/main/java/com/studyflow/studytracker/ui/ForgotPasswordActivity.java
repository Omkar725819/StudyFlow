package com.studyflow.studytracker.ui;

import android.os.Bundle;
import android.widget.EditText;
import com.studyflow.studytracker.R;

public class ForgotPasswordActivity extends BaseActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_forgot_password);
        findViewById(R.id.forgot_password_back).setOnClickListener(v -> finish());
        findViewById(R.id.recover_password_button).setOnClickListener(v -> resetPassword());
    }

    private void resetPassword() {
        String identifier = textOf(R.id.password_recovery_identifier);
        String pin = textOf(R.id.password_recovery_pin);
        String newPassword = textOf(R.id.password_recovery_new_password);
        String confirmPassword = textOf(R.id.password_recovery_confirm_password);
        if (identifier.isEmpty() || pin.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
            toast("Complete all fields");
            return;
        }
        if (!newPassword.equals(confirmPassword)) {
            toast("New passwords do not match");
            return;
        }
        if (backend.accounts().resetPassword(identifier, pin, newPassword)) {
            toast("Password updated");
            go(LoginActivity.class);
        } else {
            toast("Details are invalid or password is too short");
        }
    }

    private String textOf(int id) {
        return ((EditText) findViewById(id)).getText().toString().trim();
    }
}
