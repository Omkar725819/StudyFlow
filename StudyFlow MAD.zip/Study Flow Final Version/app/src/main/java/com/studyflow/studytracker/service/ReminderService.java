package com.studyflow.studytracker.service;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.studyflow.studytracker.data.LocalStore;
import com.studyflow.studytracker.model.Reminder;
import java.util.ArrayList;
import java.util.List;

public class ReminderService {
    public static final String EXTRA_REMINDER_ID = "reminder_id";
    public static final String EXTRA_REMINDER_NAME = "reminder_name";
    private final Context context;
    private final LocalStore store;
    private final AlarmManager alarmManager;

    public ReminderService(Context context, LocalStore store) {
        this.context = context.getApplicationContext(); this.store = store;
        this.alarmManager = (AlarmManager) this.context.getSystemService(Context.ALARM_SERVICE);
    }

    public Reminder addReminder(String name, long triggerAtMillis) {
        if (name == null || name.trim().isEmpty()) throw new IllegalArgumentException("Reminder name is required");
        if (triggerAtMillis <= System.currentTimeMillis()) throw new IllegalArgumentException("Reminder time must be in the future");
        Reminder reminder = new Reminder(name.trim(), triggerAtMillis); List<Reminder> list = store.getReminders(); list.add(reminder); store.saveReminders(list); schedule(reminder); return reminder;
    }

    public boolean cancelReminder(String id) {
        List<Reminder> list = store.getReminders(); Reminder target = null;
        for (Reminder r : list) if (r.getId().equals(id)) { target = r; break; }
        if (target == null) return false; cancelAlarm(target); target.setEnabled(false); store.saveReminders(list); return true;
    }

    public boolean deleteReminder(String id) {
        List<Reminder> list = store.getReminders(); Reminder target = null; int index = -1;
        for (int i = 0; i < list.size(); i++) if (list.get(i).getId().equals(id)) { target = list.get(i); index = i; break; }
        if (target == null) return false; cancelAlarm(target); list.remove(index); store.saveReminders(list); return true;
    }

    public boolean updateReminderName(String id, String newName) {
        if (newName == null || newName.trim().isEmpty()) return false;
        List<Reminder> list = store.getReminders();
        for (Reminder r : list) if (r.getId().equals(id)) {
            r.setName(newName.trim()); store.saveReminders(list);
            if (r.isEnabled()) schedule(r); return true;
        }
        return false;
    }

    public List<Reminder> getReminders() { return new ArrayList<>(store.getReminders()); }

    public void reschedulePendingReminders() {
        List<Reminder> list = store.getReminders();
        long now = System.currentTimeMillis();
        boolean changed = false;
        for (Reminder reminder : list) {
            if (!reminder.isEnabled()) continue;
            if (reminder.getTriggerAtMillis() > now) {
                schedule(reminder);
            } else {
                reminder.setEnabled(false);
                changed = true;
            }
        }
        if (changed) store.saveReminders(list);
    }

    public void cancelAll() {
        for (Reminder reminder : store.getReminders()) cancelAlarm(reminder);
    }

    private void schedule(Reminder reminder) {
        Intent intent = new Intent(context, ReminderReceiver.class).putExtra(EXTRA_REMINDER_ID, reminder.getId()).putExtra(EXTRA_REMINDER_NAME, reminder.getName());
        PendingIntent pending = PendingIntent.getBroadcast(context, stableRequestCode(reminder.getId()), intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (alarmManager == null) return;
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                    || alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminder.getTriggerAtMillis(), pending);
            } else {
                // Graceful fallback when the user has not granted the special exact-alarm access.
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminder.getTriggerAtMillis(), pending);
            }
        } catch (SecurityException securityException) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminder.getTriggerAtMillis(), pending);
        }
    }

    private void cancelAlarm(Reminder reminder) {
        Intent intent = new Intent(context, ReminderReceiver.class);
        PendingIntent pending = PendingIntent.getBroadcast(context, stableRequestCode(reminder.getId()), intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (alarmManager != null) alarmManager.cancel(pending);
    }
    private static int stableRequestCode(String id) { return (id == null ? 0 : id.hashCode()) & 0x7fffffff; }
}
