package com.studyflow.studytracker.ui;
import android.os.Bundle; import android.graphics.Rect; import android.widget.EditText; import android.widget.ScrollView; import com.studyflow.studytracker.R; import com.studyflow.studytracker.model.Account;
public class CreateAccountActivity extends BaseActivity {
 @Override protected void onCreate(Bundle b){
  super.onCreate(b);setContentView(R.layout.activity_create_account);
  ScrollView scroll=findViewById(R.id.create_account_scroll);
  int[] ids={R.id.create_username,R.id.create_email,R.id.create_mobile,R.id.create_password,R.id.create_confirm_password,R.id.create_security_pin,R.id.create_profession,R.id.create_education,R.id.create_college};
  for(int id:ids){ EditText field=findViewById(id); if(field!=null) field.setOnFocusChangeListener((v,hasFocus)->{ if(hasFocus) v.postDelayed(()->{ Rect rect=new Rect(0,0,v.getWidth(),v.getHeight()); v.requestRectangleOnScreen(rect,true); if(scroll!=null) scroll.smoothScrollBy(0,dp(280)); },200); }); }
  findViewById(R.id.create_back).setOnClickListener(v->finish());
  findViewById(R.id.create_account_button).setOnClickListener(v->{
   String u=t(R.id.create_username),e=t(R.id.create_email),m=t(R.id.create_mobile),p=t(R.id.create_password),cp=t(R.id.create_confirm_password),pin=t(R.id.create_security_pin),pr=t(R.id.create_profession),ed=t(R.id.create_education),c=t(R.id.create_college);
   if(!p.equals(cp)){toast("Passwords do not match");return;} if(!pin.matches("\\d{6}")){toast("Security Pin must be 6 digits");return;}
   try{Account a=new Account(u,e,m,p,pin,pr,ed,c); if(backend.accounts().createAccount(a)){go(HomeActivity.class);}else toast("Please complete all fields or account already exists");}catch(Exception ex){toast(ex.getMessage());}
  });
 }
 private String t(int id){return ((EditText)findViewById(id)).getText().toString().trim();}
}
