package com.studyflow.studytracker.ui;
import android.os.Bundle; import android.widget.EditText; import com.studyflow.studytracker.R;
public class ForgotUsernameActivity extends BaseActivity{
 @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_forgot_username); findViewById(R.id.forgot_username_back).setOnClickListener(v->finish()); findViewById(R.id.recover_username_button).setOnClickListener(v->{String r=t(R.id.recovery_identifier),p=t(R.id.recovery_security_pin); String u=backend.accounts().recoverUsername(r,p); if(u!=null){toast("Welcome back, "+u); go(HomeActivity.class);}else toast("Details do not match");});}
 private String t(int id){return ((EditText)findViewById(id)).getText().toString().trim();}
}
