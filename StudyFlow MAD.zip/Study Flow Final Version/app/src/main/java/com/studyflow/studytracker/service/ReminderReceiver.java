package com.studyflow.studytracker.service;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import androidx.core.app.NotificationCompat;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "study_flow_reminders";
    @Override public void onReceive(Context context, Intent intent) {
        String name = intent.getStringExtra(ReminderService.EXTRA_REMINDER_NAME);
        if (name == null || name.trim().isEmpty()) name = "Study Flow Reminder";
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Study Flow Reminders", NotificationManager.IMPORTANCE_HIGH);
            channel.setSound(sound, null); manager.createNotificationChannel(channel);
        }
        Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Study Flow")
                .setContentText(name).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setSound(sound);
        manager.notify(Math.abs(name.hashCode()), builder.build());
    }
}
