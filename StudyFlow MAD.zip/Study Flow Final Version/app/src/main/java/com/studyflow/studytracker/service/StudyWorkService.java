package com.studyflow.studytracker.service;

import com.studyflow.studytracker.data.LocalStore;
import com.studyflow.studytracker.model.StudyWork;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class StudyWorkService {
    private final LocalStore store;
    public StudyWorkService(LocalStore store) { this.store = store; }

    public List<StudyWork> getSubjects() { return byType(StudyWork.Type.SUBJECT); }
    public List<StudyWork> getTasks() { return byType(StudyWork.Type.TASK); }
    public List<StudyWork> getAll() { return store.getWorks(); }

    public StudyWork addSubject(String name, String semester, String education) {
        requireName(name); StudyWork s = new StudyWork(StudyWork.Type.SUBJECT, name.trim());
        s.setSemester(semester == null ? "" : semester.trim()); s.setEducation(education == null ? "" : education.trim());
        List<StudyWork> all = store.getWorks(); all.add(s); store.saveWorks(all); return s;
    }

    public StudyWork addTask(String name, String subjectId) {
        requireName(name); StudyWork t = new StudyWork(StudyWork.Type.TASK, name.trim());
        t.setSubjectId(subjectId == null ? "" : subjectId);
        List<StudyWork> all = store.getWorks(); all.add(t); store.saveWorks(all); return t;
    }

    public boolean update(StudyWork updated) {
        if (updated == null) return false; List<StudyWork> all = store.getWorks();
        for (int i=0; i<all.size(); i++) if (all.get(i).getId().equals(updated.getId())) { all.set(i, updated); store.saveWorks(all); return true; }
        return false;
    }

    public boolean delete(String workId) {
        if (workId == null || workId.trim().isEmpty()) return false;
        List<StudyWork> all = store.getWorks();
        Set<String> removedIds = new HashSet<>();
        for (StudyWork w : all) {
            if (w.getId().equals(workId) || (w.getType() == StudyWork.Type.TASK && workId.equals(w.getSubjectId()))) {
                removedIds.add(w.getId());
            }
        }
        if (removedIds.isEmpty()) return false;
        all.removeIf(w -> removedIds.contains(w.getId()));
        store.saveWorks(all);
        store.removeSessionsForWorks(removedIds);
        return true;
    }

    public boolean resetProgress(String workId) {
        if (workId == null || workId.trim().isEmpty()) return false;
        List<StudyWork> all = store.getWorks();
        for (StudyWork w : all) {
            if (w.getId().equals(workId)) {
                w.resetProgress();
                store.saveWorks(all);
                store.removeSessionsForWork(workId);
                return true;
            }
        }
        return false;
    }

    public void resetAllProgress() {
        List<StudyWork> all = store.getWorks();
        for (StudyWork w : all) w.resetProgress();
        store.saveWorks(all);
        store.saveSessions(new ArrayList<>());
    }

    public boolean setSubjectTarget(String subjectId, long targetMillis) {
        List<StudyWork> all = store.getWorks();
        for (StudyWork w : all) if (w.getId().equals(subjectId) && w.getType() == StudyWork.Type.SUBJECT) {
            w.setTargetMillis(targetMillis); store.saveWorks(all); return true;
        }
        return false;
    }

    public StudyWork find(String id) { for (StudyWork w : store.getWorks()) if (w.getId().equals(id)) return w; return null; }

    private List<StudyWork> byType(StudyWork.Type type) {
        List<StudyWork> result = new ArrayList<>(); for (StudyWork w : store.getWorks()) if (w.getType() == type) result.add(w); return result;
    }
    private static void requireName(String name) { if (name == null || name.trim().isEmpty()) throw new IllegalArgumentException("Name is required"); }
}
