package com.studyflow.studytracker.service;

import com.studyflow.studytracker.data.LocalStore;

/** Stopwatch state survives Activity recreation and process restarts until explicitly paused/saved. */
public class StopwatchService {
    private final LocalStore store;
    private String workId;
    private long accumulatedMillis;
    private long startedAtMillis;
    private boolean running;

    public StopwatchService(LocalStore store) {
        this.store = store;
        restore();
    }

    private void restore() {
        workId = store.getStopwatchWorkId();
        if (workId != null && workId.trim().isEmpty()) workId = null;
        accumulatedMillis = store.getStopwatchAccumulatedMillis();
        startedAtMillis = store.getStopwatchStartedAtMillis();
        running = store.isStopwatchRunning() && workId != null;
        if (running && startedAtMillis <= 0L) {
            running = false;
            persist();
        }
    }

    public void selectWork(String workId) {
        // Never reset a running session merely because a page recreated or refreshed.
        if (running && this.workId != null && this.workId.equals(workId)) return;
        this.workId = workId;
        if (!running) reset(); else persist();
    }

    public String getWorkId() { return workId; }

    public void start() {
        if (workId == null || running) return;
        startedAtMillis = System.currentTimeMillis();
        running = true;
        persist();
    }

    public void pause() {
        if (!running) return;
        accumulatedMillis += System.currentTimeMillis() - startedAtMillis;
        running = false;
        startedAtMillis = 0L;
        persist();
    }

    public void resume() { if (!running && workId != null) { startedAtMillis = System.currentTimeMillis(); running = true; persist(); } }

    public long getElapsedMillis() {
        return running ? accumulatedMillis + Math.max(0L, System.currentTimeMillis() - startedAtMillis) : accumulatedMillis;
    }

    public boolean isRunning() { return running; }

    public long stopAndRead() { pause(); return accumulatedMillis; }

    public long saveAndReset() { pause(); long result = accumulatedMillis; reset(); return result; }

    public void reset() { accumulatedMillis = 0L; startedAtMillis = 0L; running = false; persist(); }

    private void persist() { store.saveStopwatchState(workId, accumulatedMillis, startedAtMillis, running); }
}
