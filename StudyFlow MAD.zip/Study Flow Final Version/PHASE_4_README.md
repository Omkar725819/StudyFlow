# Study Flow — Phase 4: Gradle Configuration

## Toolchain
- Android Studio: Quail 4 (2026.1.4)
- Android Gradle Plugin: 9.4.0
- Gradle wrapper distribution: 9.7.1
- JDK: 17+
- compileSdk: 36
- targetSdk: 36
- minSdk: 31
- Language: Java
- UI: XML
- Build script: Gradle Kotlin DSL (.kts)

## Dependencies
- androidx.appcompat:appcompat:1.8.0
- androidx.core:core:1.17.0

## Notes
AGP 9.4.0 is the stable plugin paired with Android Studio Quail 4 (2026.1.4). AGP 9.4.0 requires Gradle 9.6.0 or newer and JDK 17+; this project uses Gradle 9.7.1 with JDK 25 runtime compatibility. The project intentionally remains dependency-light and fully offline at runtime.

A full APK build was not executed in this environment because the Android SDK and Gradle distribution are not installed/cached here. The Gradle configuration itself has been created and the source/resource structure has been checked for the required package, manifests, layouts, and resource references.
