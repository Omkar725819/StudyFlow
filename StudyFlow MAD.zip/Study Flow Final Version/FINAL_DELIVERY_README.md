# Study Flow — Corrected Final Project

This package is the corrected project after a direct audit of the previously delivered codebase.

## Important corrections made during the audit

1. Fixed a critical Tasks screen refresh bug. The dynamic list container is now retained instead of being destroyed through the placeholder view, so add/edit/delete/reset operations can render correctly after the first refresh.
2. Rebuilt Forgot Password as a real password-reset flow using identifier + 6-digit security PIN + new password + confirmation, then returning to Login.
3. Forgot Username now follows the requested direct recovery-to-Home workflow after successful verification.
4. Fixed the AppCompat runtime theme mismatch. Activities extend `AppCompatActivity` and now use `Theme.AppCompat` descendants.
5. Dark Mode now persists when the Switch itself is tapped, not only when the surrounding row is tapped.
6. Account editing now includes the security PIN and validates it through the existing account validation rules.
7. Logout now cancels scheduled reminders before clearing local study data, preventing orphan alarms from firing after logout.
8. Added boot/time-change reminder rescheduling for enabled future reminders.
9. Removed plaintext fallback from password verification for malformed legacy values.
10. Hardened reminder PendingIntent request-code generation against the `Integer.MIN_VALUE` edge case.
11. Guest-created study data is cleared when converting the device state into a newly created account, preventing accidental guest-data carryover.
12. Task editing now supports both task name/details and its related subject.
13. Subject editing now uses the supplied XML edit form for name, semester, and education.
14. Task cards now display their related subject when available.

## Verification performed in this environment

- XML parsing: PASS — 55 XML resource files parsed successfully.
- Java source delimiter/static structure scan: PASS — 29 Java source files checked.
- Java-to-XML ID reference scan: PASS — no missing application `R.id` references.
- Java-to-layout reference scan: PASS — no missing application layout references.
- Application color reference scan: PASS.
- Password authentication test: PASS — username/email/mobile login, wrong-password rejection, username recovery, and password reset.
- Core model/time-format test: PASS — progress counters, reset behavior, and HH:MM:SS formatting.

`android.R.drawable.ic_dialog_info` is an intentional framework resource and is not an application drawable; it is therefore excluded from the application-drawable reference check.

## Build verification limitation

A full Android APK build was not executed in this container because the Android SDK and a usable Gradle runtime/wrapper JAR are not installed here. The Gradle configuration targets Android Studio Quail 4 / 2026.1.4 with AGP 9.4.0 and Gradle 9.7.1. The project should still be opened and synced in Android Studio and then built on a machine with the required SDK components installed.

## Project requirements retained

- Java for application logic
- XML for UI
- Offline-first local persistence
- Minimum Android API 31
- Target Android API 36
- Gradle Kotlin DSL
- No cloud database/API key requirement for core functionality
